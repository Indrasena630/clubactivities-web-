//
//  fattendnceTableViewCell.swift
//  clubactivity
//
//  Created by SAIL on 11/10/23.
//

import UIKit

class fattendnceTableViewCell: UITableViewCell {
    @IBOutlet weak var title: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
