//
//  StatusViewController.swift
//  clubactivity
//
//  Created by SAIL on 09/10/23.
//

import UIKit

class StatusViewController: BasicViewController {
    
    var statusStudent : StudentStatusModel!
     
    @IBOutlet weak var statusTableView: UITableView!
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        GetAPI()
    }
    
    func GetAPI(){
        let apiURL = APIList().urlString(url:.StudentStatus)+"userid=\( UserDefaultsManager.shared.getUserID() ?? "")"
        self.startIndicator()
        print(apiURL)
           APIHandler().getAPIValues(type: StudentStatusModel.self, apiUrl: apiURL, method: "GET") {  result in
               switch result {
               case .success(let data):
                   self.statusStudent = data
                 print(data)
                   if self.statusStudent.status == true{
                       DispatchQueue.main.async {
                           self.stopIndicator()
                           self.statusTableView.reloadData()
                      }
                   }
                   else if self.statusStudent.status == false{
                       self.showToast(self.statusStudent.message)
                   }
                   case .failure(let error):
                   print(error)
                   DispatchQueue.main.async {
                   let alert = UIAlertController(title: "Warning", message: "Something Went Error", preferredStyle: .alert)
                   alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { ok in
                       print("JSON Error")
                   })
                   self.present(alert, animated: true, completion: nil)
                   }
               }
           }
    }
    
    @IBAction func backButton(_ sender: UIButton) {
        
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func menuButton(_ sender: UIButton) {
        
        
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "MenuViewController") as! MenuViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
extension StatusViewController : UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return statusStudent?.coursedata.count ?? 0
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell =  tableView.dequeueReusableCell(withIdentifier: "statusCell") as! statusCell
        cell.backgroundColor = UIColor.white
        cell.View.layer.borderColor = UIColor.black.cgColor
        cell.View.layer.borderWidth = 1
        cell.View.layer.cornerRadius = 8
        cell.View.clipsToBounds = true
        cell.clubCodeLabel.text = statusStudent?.coursedata[indexPath.row].clubCode
        cell.clubNameLabel.text = statusStudent?.coursedata[indexPath.row].clubName
        cell.statusLabel.text = statusStudent?.coursedata[indexPath.row].status
        cell.feedBackLabel.text = statusStudent?.coursedata[indexPath.row].feedback
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 150
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        

    }
    
}

class statusCell : UITableViewCell{
    
    @IBOutlet weak var View: UIView!

    @IBOutlet weak var clubCodeLabel: UILabel!
    
    @IBOutlet weak var clubNameLabel: UILabel!
    
    @IBOutlet weak var statusLabel: UILabel!
    
    @IBOutlet weak var feedBackLabel: UILabel!
        
   
    
}

