//
//  LoginViewController.swift
//  clubactivity
//
//  Created by SAIL on 09/10/23.
//

import UIKit

class LoginViewController: BasicViewController {
    
    @IBOutlet weak var userNameTextField : UITextField!
    @IBOutlet weak var passwordTextField : UITextField!
    
    var logInAdmin : AdminLoginModel!
    var logInStudent : studentLoginModel!
    var logInFaculty : facultyLoginModel!
    
    


    override func viewDidLoad() {
        super.viewDidLoad()
       
    }
    
    
    
    
    
  

    

   

    
    @IBAction func backButton(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func logInButton(_ sender: UIButton) {

        if userNameTextField.text?.isEmpty == true {
            self.showToast("Enter the UserName")
        }else if passwordTextField.text?.isEmpty == true {
            self.showToast("Enter the Password")
        }else {
            
            self.GetAPI()
        }
    }
    
    
    func GetAPI(){
        var apiURL = ""
        
        if (UserDefaultsManager.shared.getUserName() == "Student"){
            
            UserDefaultsManager.shared.saveUserID(userNameTextField.text ?? "")
            
             apiURL = APIList().urlString(url:.StudentLogin)+"studentid=\(userNameTextField.text ?? "")&password=\(passwordTextField.text ?? "")"
            print(apiURL)
            self.startIndicator()
           APIHandler().getAPIValues(type: studentLoginModel.self, apiUrl: apiURL, method: "GET") {  result in
            switch result {
               case .success(let data):
                   self.logInStudent = data
                 print(data)
                   if self.logInStudent.status == true{
                       DispatchQueue.main.async {
                           self.stopIndicator()
                           let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "CalenderViewController") as! CalenderViewController
                           self.navigationController?.pushViewController(nextVC, animated: true) }
                   }
                   else if self.logInStudent.status == false{
                       self.showToast(self.logInStudent.message)
                   }
                   case .failure(let error):
                   print(error)
                   DispatchQueue.main.async {
                       self.stopIndicator()
                   let alert = UIAlertController(title: "OOPS", message: "Something went Wrong", preferredStyle: .alert)
                   alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { ok in
                       print("JSON Error")
                   })
                   self.present(alert, animated: true, completion: nil)
                   }
               }
           }
            
        } else if  (UserDefaultsManager.shared.getUserName() == "Faculty") {
            UserDefaultsManager.shared.saveUserID(userNameTextField.text ?? "")
            apiURL = APIList().urlString(url:.FacultyLogin)+"facultyid=\(userNameTextField.text ?? "")&password=\(passwordTextField.text ?? "")"
            print(apiURL)
            self.startIndicator()
           APIHandler().getAPIValues(type: facultyLoginModel.self, apiUrl: apiURL, method: "GET") {  result in
            switch result {
               case .success(let data):
                   self.logInFaculty = data
                 print(data)
                   if self.logInFaculty.status == true{
                       DispatchQueue.main.async {
                           self.stopIndicator()
                           let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "CalenderViewController") as! CalenderViewController
                           self.navigationController?.pushViewController(nextVC, animated: true) }
                   }
                   else if self.logInFaculty.status == false{
                       self.showToast(self.logInFaculty.message)
                   }
                   case .failure(let error):
                   print(error)
                   DispatchQueue.main.async {
                       self.stopIndicator()
                   let alert = UIAlertController(title: "OOPS", message: "Something went Wrong", preferredStyle: .alert)
                   alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { ok in
                       print("JSON Error")
                   })
                   self.present(alert, animated: true, completion: nil)
                   }
               }
           }
        }else if (UserDefaultsManager.shared.getUserName() == "Admin"){
            UserDefaultsManager.shared.saveUserID(userNameTextField.text ?? "")
            apiURL = APIList().urlString(url:.AdminLogin)+"username=\(userNameTextField.text ?? "")&Password=\(passwordTextField.text ?? "")"
            print(apiURL)
            self.startIndicator()
           APIHandler().getAPIValues(type: AdminLoginModel.self, apiUrl: apiURL, method: "GET") {  result in
            switch result {
               case .success(let data):
                   self.logInAdmin = data
                 print(data)
                   if self.logInAdmin.status == true{
                       DispatchQueue.main.async {
                           self.stopIndicator()
                           let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "CalenderViewController") as! CalenderViewController
                           self.navigationController?.pushViewController(nextVC, animated: true) }
                   }
                   else if self.logInAdmin.status == false{
                       self.showToast(self.logInAdmin.message)
                   }
                   case .failure(let error):
                   print(error)
                   DispatchQueue.main.async {
                       self.stopIndicator()
                   let alert = UIAlertController(title: "OOPS", message: "Something went Wrong", preferredStyle: .alert)
                   alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { ok in
                       print("JSON Error")
                   })
                   self.present(alert, animated: true, completion: nil)
                   }
               }
           }
        }
          
    }

    


}
