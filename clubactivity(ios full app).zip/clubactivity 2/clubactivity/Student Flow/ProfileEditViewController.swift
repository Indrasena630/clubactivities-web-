//
//  ProfileEditViewController.swift
//  clubactivity
//
//  Created by SAIL on 09/10/23.
//

import UIKit

class ProfileEditViewController: BasicViewController {
    
    @IBOutlet weak var nameLabel: UILabel!
    
    @IBOutlet weak var phoneNoLabel: UILabel!
    
    @IBOutlet weak var emailLabel: UILabel!
    
    @IBOutlet weak var dobLabel: UILabel!
  
    @IBOutlet weak var passwordLabel: UILabel!
    
    @IBOutlet weak var addressLabel: UILabel!
    
    var studentEditProfile : StudentProfileModel?
    var facultyEditProfile : FacultyProfileEditModel?

    override func viewDidLoad() {
        super.viewDidLoad()
        self.GetAPI()
    }
    override func viewWillAppear(_ animated: Bool) {
        self.GetAPI()
    }
    
    func GetAPI(){
        if UserDefaultsManager.shared.getUserName() == "Student"{
            let apiURL = APIList().urlString(url:.StudentProfile)+"studentid=\( UserDefaultsManager.shared.getUserID() ?? "")"
            self.startIndicator()
            print(apiURL)
               APIHandler().getAPIValues(type: StudentProfileModel.self, apiUrl: apiURL, method: "GET") {  result in
                   switch result {
                   case .success(let data):
                       self.studentEditProfile = data
                     print(data)
                       if self.studentEditProfile?.status == true{
                           DispatchQueue.main.async {
                               self.stopIndicator()
                               self.nameLabel.text = self.studentEditProfile?.data.name
                               self.phoneNoLabel.text = self.studentEditProfile?.data.contact
                               self.emailLabel.text = self.studentEditProfile?.data.email
                               self.dobLabel.text = self.studentEditProfile?.data.dob
                               self.passwordLabel.text = self.studentEditProfile?.data.password
                               self.addressLabel.text = self.studentEditProfile?.data.address
                          }
                       }
                       else if self.studentEditProfile?.status == false{
                           self.showToast(self.studentEditProfile?.message ?? "Error")
                       }
                       case .failure(let error):
                       print(error)
                       DispatchQueue.main.async {
                       let alert = UIAlertController(title: "Warning", message: "Something Went Error", preferredStyle: .alert)
                       alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { ok in
                           print("JSON Error")
                       })
                       self.present(alert, animated: true, completion: nil)
                       }
                   }
               }
        }else{
            let apiURL = APIList().urlString(url:.FacultyProfile)+"facultyid=\( UserDefaultsManager.shared.getUserID() ?? "")"
            self.startIndicator()
            print(apiURL)
               APIHandler().getAPIValues(type: FacultyProfileEditModel.self, apiUrl: apiURL, method: "GET") {  result in
                   switch result {
                   case .success(let data):
                       self.facultyEditProfile = data
                     print(data)
                       if self.facultyEditProfile?.status == true{
                           DispatchQueue.main.async {
                               self.stopIndicator()
                               self.nameLabel.text = self.facultyEditProfile?.data.name
                               self.phoneNoLabel.text = self.facultyEditProfile?.data.contact
                               self.emailLabel.text = self.facultyEditProfile?.data.email
                               self.dobLabel.text = self.facultyEditProfile?.data.dob
                               self.passwordLabel.text = self.facultyEditProfile?.data.password
                               self.addressLabel.text = self.facultyEditProfile?.data.address
                          }
                       }
                       else if self.facultyEditProfile?.status == false{
                           self.showToast(self.facultyEditProfile?.message ?? "Error")
                       }
                       case .failure(let error):
                       print(error)
                       DispatchQueue.main.async {
                       let alert = UIAlertController(title: "Warning", message: "Something Went Error", preferredStyle: .alert)
                       alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { ok in
                           print("JSON Error")
                       })
                       self.present(alert, animated: true, completion: nil)
                       }
                   }
               }
        }
        
    }
    
 
    @IBAction func Edit(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ProfileSaveViewController") as! ProfileSaveViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func backbutton(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func menubutton(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "MenuViewController") as! MenuViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
}

    

