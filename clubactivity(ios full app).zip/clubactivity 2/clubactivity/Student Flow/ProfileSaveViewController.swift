//
//  ProfileSaveViewController.swift
//  clubactivity
//
//  Created by SAIL on 09/10/23.
//

import UIKit

class ProfileSaveViewController: BasicViewController {
    
    
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var contectNumberTextField: UITextField!
    @IBOutlet weak var dOBTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var addressTextField: UITextField!
    
    var profileSaveData : StudentEditProfileModel!
    var facultyprofileSaveData : FacultyProfileSaveModel!
    
    var formData : [String:String] = [:]
    let datePicker : UIDatePicker = UIDatePicker()
    override func viewDidLoad() {
        super.viewDidLoad()

        dOBTextField.tag = 0
      
    }
    
   
    @IBAction func dateTextFieldBeginEditing(_ sender: UITextField) {
        showDatePicker(tag: sender.tag)
    }
    func showDatePicker(tag: Int){
        datePicker.datePickerMode = .date
        if #available(iOS 13.4, *) { datePicker.preferredDatePickerStyle = .inline }
        else { datePicker.preferredDatePickerStyle = .wheels }
        datePicker.maximumDate = Calendar.current.date(byAdding: .year, value: 0, to: Date())
        let toolbar = UIToolbar()
        toolbar.sizeToFit()
        let doneButton = UIBarButtonItem(title: "Done", style: UIBarButtonItem.Style.done, target: self, action: #selector(self.donedatePicker(_ :)))
        doneButton.tag = tag
        let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.flexibleSpace, target: nil, action: nil)
        let cancelButton = UIBarButtonItem(title: "Cancel", style: UIBarButtonItem.Style.plain, target: self, action: #selector(self.cancelDatePicker(_ :)))
        cancelButton.tag = tag
        toolbar.setItems([cancelButton ,spaceButton,doneButton], animated: false)
        self.dOBTextField.inputAccessoryView = toolbar
        self.dOBTextField.inputView = datePicker
    }
    @objc func cancelDatePicker(_ sender: UIButton){
        self.dOBTextField.text? = ""
        self.view.endEditing(true)
    }
    @objc func donedatePicker(_ sender: UIButton){
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        datePicker.maximumDate = Calendar.current.date(byAdding: .year, value: 0, to: Date())
        self.dOBTextField.text = formatter.string(from: datePicker.date)
        self.view.endEditing(true)
    }
    
    @IBAction func Save(_ sender: Any) {
        if nameTextField.text?.isEmpty == true{
            showToast("Enter the Name")
        }else if passwordTextField.text?.isEmpty == true{
            showToast("Enter the Password")
        }else if contectNumberTextField.text?.isEmpty == true{
            showToast("Enter the Contact NO.")
        }else if addressTextField.text?.isEmpty == true{
            showToast("Enter the Address")
        }else if dOBTextField.text?.isEmpty == true{
            showToast("Enter the DOB")
        }else if emailTextField.text?.isEmpty == true{
            showToast("Enter the Email ID")
        }else{
            if !isValidPhone(testStr: contectNumberTextField.text ?? "Empty"){
                showToast("Enter the Valid Contact Number")
            }else if !isValidEmail(emailStr: emailTextField.text ?? "Empty"){
                showToast("Enter the Valid Email Format")
            }else {
                self.GetAPI()
            }
        }
       
        }
        
    @IBAction func backbutton(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func menubutton(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "MenuViewController") as! MenuViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
extension ProfileSaveViewController{
    
    func GetAPI(){
        if UserDefaultsManager.shared.getUserName() == "Student"{
        
        let apiURL = APIList().urlString(url:.StudentEditProfile)
        self.startIndicator()
        formData = ["studentid":"\(UserDefaultsManager.shared.getUserID() ?? "0")","name":"\(nameTextField.text ?? "Error")",
                   "contact":"\(contectNumberTextField.text ?? "Error")",
                   "address":"\(addressTextField.text ?? "Error")",
                   "dob":"\(dOBTextField.text ?? "Error")",
                   "password":"\(passwordTextField.text ?? "Error")",
                   "email":"\(emailTextField.text ?? "Error")"]
                   
                   APIHandler().postAPIValues(type: StudentEditProfileModel.self, apiUrl: apiURL, method: "POST", formData: formData) {  result in
               switch result {
               case .success(let data):
                   self.profileSaveData = data
                 print(data)
                   if self.profileSaveData.success == true{
                       DispatchQueue.main.async { [self] in
                           showToast(self.profileSaveData.message)
                           self.stopIndicator()
                           self.navigationController?.popViewController(animated: true)
                          
                      }
                   }
                   else if self.profileSaveData.success == false{
                       DispatchQueue.main.async {
                           self.stopIndicator()
                           self.showToast(self.profileSaveData.message)
                       }
                       
                   }
                   case .failure(let error):
                   print(error)
                   DispatchQueue.main.async {

                       self.stopIndicator()
                   let alert = UIAlertController(title: "Warning", message: "Something Went Error", preferredStyle: .alert)
                   alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { ok in
                       print("JSON Error")
                   })
                   self.present(alert, animated: true, completion: nil)
                   }
               }
           }
        }else if UserDefaultsManager.shared.getUserName() == "Faculty"{
                    
                    let apiURL = APIList().urlString(url:.FacultyEditProfile)
                    self.startIndicator()
                print(apiURL)
                    formData = ["facultyid":"\(UserDefaultsManager.shared.getUserID() ?? "Error")","name":"\(nameTextField.text ?? "Error")",
                               "contact":"\(contectNumberTextField.text ?? "Error")",
                               "address":"\(addressTextField.text ?? "Error")",
                               "dob":"\(dOBTextField.text ?? "Error")",
                               "password":"\(passwordTextField.text ?? "Error")",
                               "email":"\(emailTextField.text ?? "Error")"]
                               
                               APIHandler().postAPIValues(type: FacultyProfileSaveModel.self, apiUrl: apiURL, method: "POST", formData: formData) {  result in
                           switch result {
                           case .success(let data):
                               self.facultyprofileSaveData = data
                             print(data)
                               if self.facultyprofileSaveData.success == true{
                                   DispatchQueue.main.async { [self] in
                                       showToast(self.facultyprofileSaveData.message)
                                      
                                       self.navigationController?.popViewController(animated: true)
                                      
                                  }
                               }
                               else if self.facultyprofileSaveData.success == false{
                                   DispatchQueue.main.async {
                                       self.stopIndicator()
                                   self.showToast(self.facultyprofileSaveData.message)
                                   }
                               }
                               case .failure(let error):
                               print(error)
                               DispatchQueue.main.async {

                                   self.stopIndicator()
                               let alert = UIAlertController(title: "Warning", message: "Something Went Error", preferredStyle: .alert)
                               alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { ok in
                                   print("JSON Error")
                               })
                               self.present(alert, animated: true, completion: nil)
                               }
                           }
                               }
        }
        
    }
}



