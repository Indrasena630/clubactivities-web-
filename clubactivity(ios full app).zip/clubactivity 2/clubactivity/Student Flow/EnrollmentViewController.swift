//
//  EnrollmentViewController.swift
//  clubactivity
//
//  Created by SAIL on 09/10/23.
//

import UIKit

class EnrollmentViewController: BasicViewController{
    
    var studentenrollment : EnrollmentViewModel!
    var studentpostenrollment : EnrollmentPostModel!
    var selectedCourse: coursedatas?
    var selectedIndexPath: IndexPath?




   
    @IBOutlet weak var enrollmentTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.GetAPI()
    }
    
    func GetAPI(){
        let apiURL = APIList().urlString(url:.GetEnrollment)
        self.startIndicator()
        print(apiURL)
           APIHandler().getAPIValues(type: EnrollmentViewModel.self, apiUrl: apiURL, method: "GET") {  result in
               switch result {
               case .success(let data):
                   self.studentenrollment = data
                 print(data)
                   if self.studentenrollment.status == true{
                       DispatchQueue.main.async {
                           self.stopIndicator()
                           self.enrollmentTableView.reloadData()
                           self.showToast(self.studentenrollment.message)
                      }
                   }
                   else if self.studentenrollment.status == false{
                       self.showToast(self.studentenrollment.message)
                   }
                   case .failure(let error):
                   print(error)
                   DispatchQueue.main.async {
                   let alert = UIAlertController(title: "Warning", message: "Something Went Error", preferredStyle: .alert)
                   alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { ok in
                       print("JSON Error")
                   })
                   self.present(alert, animated: true, completion: nil)
                   }
               }
           }
    }
    
    func postAPI(courseID: String){
    
        self.startIndicator()
        let apiURL = APIList().urlString(url:.PostEnrollment)
        
        let formData = ["courseid":courseID,
                        "studentid":"\(UserDefaultsManager.shared.getUserID() ?? "Error")"]
        print(apiURL)
        print(formData)
        APIHandler().postAPIValues(type: EnrollmentPostModel.self, apiUrl: apiURL, method: "POST", formData: formData) {  result in
               switch result {
               case .success(let data):
                   self.studentpostenrollment = data
                 print(data)
                   if self.studentpostenrollment.status == true{
                       DispatchQueue.main.async { [self] in
                           self.stopIndicator()
                           showToast(self.studentpostenrollment.message)
                           self.showAlert(title: "Success", message: data.message, okActionHandler: {
                               let vc = self.storyboard?.instantiateViewController(withIdentifier: "CalenderViewController") as! CalenderViewController
                               self.navigationController?.pushViewController(vc, animated: true)
                           })

                      }
                   }
                   else if self.studentpostenrollment.status == false{
                   }
                   case .failure(let error):
                   print(error)
                   DispatchQueue.main.async {

                   let alert = UIAlertController(title: "Warning", message: "Something Went Error", preferredStyle: .alert)
                   alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { ok in
                       print("JSON Error")
                   })
                   self.present(alert, animated: true, completion: nil)
                   }
               }
           }
    }
    
    @IBAction func menubutton(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "MenuViewController") as! MenuViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func backbutton(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func submitButtonAction(_ sender : UIButton){

        if let selectedCourse = selectedCourse {
                print("Selected Course ID: \(selectedCourse.courseID)")
                postAPI(courseID: selectedCourse.courseID)
            } else {
                print("NOthing")
            }
    }
   
}
extension EnrollmentViewController : UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return studentenrollment?.courses.count ?? 0
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell =  tableView.dequeueReusableCell(withIdentifier: "enrollmentCell") as! enrollmentCell
        cell.backgroundColor = UIColor.white
        cell.View.layer.borderColor = UIColor.black.cgColor
        cell.View.layer.borderWidth = 1
        cell.View.layer.cornerRadius = 8
        cell.View.backgroundColor = UIColor.systemGray6
        cell.View.clipsToBounds = true
       
        cell.courseNameLabel.text = "\(studentenrollment?.courses[indexPath.row].courseID ?? "")" + " - " + "\( studentenrollment?.courses[indexPath.row].courseName ?? "")"
        cell.noOfStudentsLabel.text =  studentenrollment?.courses[indexPath.row].strength
        if indexPath == tableView.indexPathForSelectedRow {
                cell.View.backgroundColor = UIColor.systemBlue
            } else {
                cell.View.backgroundColor = UIColor.systemGray6
            }
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let cell = tableView.cellForRow(at: indexPath) as? enrollmentCell {
                cell.View.backgroundColor = UIColor.lightGray
        }
            selectedCourse = studentenrollment?.courses[indexPath.row]
    }
    func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
        if let cell = tableView.cellForRow(at: indexPath) as? enrollmentCell {
            cell.View.backgroundColor = UIColor.white
        }
    }

}

class enrollmentCell : UITableViewCell{
    @IBOutlet weak var View: UIView!
    @IBOutlet weak var courseNameLabel: UILabel!
    @IBOutlet weak var noOfStudentsLabel: UILabel!
    }
