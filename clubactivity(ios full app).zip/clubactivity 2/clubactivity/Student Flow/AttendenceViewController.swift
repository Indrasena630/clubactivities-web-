//
//  AttendenceViewController.swift
//  clubactivity
//
//  Created by SAIL on 09/10/23.
//

import UIKit

class AttendenceViewController: BasicViewController {
    
    var studentattendence : StudentAttendenceModel!
     
    @IBOutlet weak var studentAttendenceTableView: UITableView!
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        GetAPI()
    }
    
    func GetAPI(){
        let apiURL = APIList().urlString(url:.StudentAttendence)+"id=\( UserDefaultsManager.shared.getUserID() ?? "")"
        self.startIndicator()
        print(apiURL)
           APIHandler().getAPIValues(type: StudentAttendenceModel.self, apiUrl: apiURL, method: "GET") {  result in
               switch result {
               case .success(let data):
                   self.studentattendence = data
                 print(data)
                   if self.studentattendence.status == true{
                       DispatchQueue.main.async {
                           self.stopIndicator()
                           self.studentAttendenceTableView.reloadData()
                      }
                   }
                   else if self.studentattendence.status == false{
                       self.stopIndicator()
                       self.showToast(self.studentattendence.message)
                   }
                   case .failure(let error):
                   print(error)
                   DispatchQueue.main.async {
                   let alert = UIAlertController(title: "Warning", message: "Something Went Error", preferredStyle: .alert)
                   alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { ok in
                       self.stopIndicator()
                       print("JSON Error")
                   })
                   self.present(alert, animated: true, completion: nil)
                   }
               }
           }
    }
    
    @IBAction func backButton(_ sender: UIButton) {
        
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func menuButton(_ sender: UIButton) {
        
        
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "MenuViewController") as! MenuViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
extension AttendenceViewController : UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return studentattendence?.coursedata.count ?? 0
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell =  tableView.dequeueReusableCell(withIdentifier: "StudentAttendenceCell") as! StudentAttendenceCell
        cell.backgroundColor = UIColor.white
        cell.View.layer.borderColor = UIColor.black.cgColor
        cell.View.layer.borderWidth = 1
        cell.View.layer.cornerRadius = 8
        cell.View.clipsToBounds = true
        cell.clubCodeLabel.text = studentattendence?.coursedata[indexPath.row].clubCode
        cell.clubNameLabel.text = studentattendence?.coursedata[indexPath.row].clubName
        cell.totalClassesLabel.text =  studentattendence?.coursedata[indexPath.row].totalClasses
        cell.classesAttendenceLabel.text = studentattendence?.coursedata[indexPath.row].classesAttended
        cell.percentageLabel.text = "\(studentattendence?.coursedata[indexPath.row].percentage ?? 0)"
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 150
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        

    }
    
}

class StudentAttendenceCell : UITableViewCell{
    
    @IBOutlet weak var View: UIView!

    @IBOutlet weak var clubCodeLabel: UILabel!
    
    @IBOutlet weak var clubNameLabel: UILabel!
    
    @IBOutlet weak var totalClassesLabel: UILabel!
    
    @IBOutlet weak var classesAttendenceLabel: UILabel!
        
    @IBOutlet weak var percentageLabel: UILabel!
    
}

