//
//  AllLoginPageViewController.swift
//  clubactivity
//
//  Created by SAIL on 09/10/23.
//

import UIKit

class AllLoginPageViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        self.navigationController?.navigationBar.isHidden = true
    }
    

    @IBAction func studentLogin(_ sender: Any) {
        UserDefaultsManager.shared.saveUserName("Student")
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "LoginViewController") as! LoginViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    @IBAction func facultyLogin(_ sender: Any) {
        UserDefaultsManager.shared.saveUserName("Faculty")
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "LoginViewController") as! LoginViewController
        self.navigationController?.pushViewController(vc, animated: true)
        
        
    }
    @IBAction func adminLogin(_ sender: Any) {
        UserDefaultsManager.shared.saveUserName("Admin")
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "LoginViewController") as! LoginViewController
        self.navigationController?.pushViewController(vc, animated: true)
        
        
    }

}
