//
//  MenuViewController.swift
//  clubactivity
//
//  Created by SAIL on 09/10/23.
//

import UIKit

class MenuViewController: UIViewController {
    
    var studentFlow = ["Home","Enrollment","Attendence","Status","Profile","Logout"]
    
    var facultyFlow = ["Home","Registration","Attendence","Course Attendence","Grade Marking","Profile","Log out"]
    
    var adminFlow = ["Home","Manage Students","Manage Faculties","Events","Log out"]
    
    var studentImage = ["home 1","calendar (1) 1","calendar (1) 1","vows 1","user 1","logout 1"]
    
    var facultyImage = ["home 1","image 8","calendar (1) 1","calendar (1) 1","homework 1","user 1","logout 1"]
    
    var adminImage = ["home 1","setting 1","setting 1","calendar (1) 1","logout 1"]
    
    var conditionCheck = UserDefaultsManager.shared.getUserName()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    

    @IBAction func backButton(_ sender: UIButton) {
        
        self.navigationController?.popViewController(animated: true)
    }
    
   
    
}

extension MenuViewController : UITableViewDelegate, UITableViewDataSource{
    
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            if UserDefaultsManager.shared.getUserName() == "Student"{
                return studentFlow.count
            }else if UserDefaultsManager.shared.getUserName() == "Faculty"{
                return facultyFlow.count
            }else if UserDefaultsManager.shared.getUserName() == "Admin"{
                return adminFlow.count
            }else{
                return 1
            }
        }
    
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            
            let cell = tableView.dequeueReusableCell(withIdentifier: "MenuTableViewCell", for: indexPath) as! MenuTableViewCell
 
            cell.View?.layer.cornerRadius = 8
            
            if UserDefaultsManager.shared.getUserName() == "Student"{
                
                cell.Label.text = studentFlow[indexPath.row]
                
                let imageName = studentImage[indexPath.row]
                        if let image = UIImage(named: imageName) {
                            cell.imageView?.image = image
                        }
            }else if UserDefaultsManager.shared.getUserName() == "Faculty"{
                cell.Label.text = facultyFlow[indexPath.row]
                let imageName = facultyImage[indexPath.row]
                            if let image = UIImage(named: imageName) {
                                cell.imageView?.image = image
                            }
            }else if UserDefaultsManager.shared.getUserName() == "Admin"{
                cell.Label.text = adminFlow[indexPath.row]
                let imageName = adminImage[indexPath.row]
                            if let image = UIImage(named: imageName) {
                                cell.imageView?.image = image
                            }
            }
            return cell
            
        }
        
        
        
        func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
            return 100
        }
        func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
            
            if conditionCheck == "Student"{
            if indexPath.row == 0 {
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "CalenderViewController" ) as! CalenderViewController
                self.navigationController?.pushViewController(vc, animated: true)
            }else if indexPath.row == 1{
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "EnrollmentViewController" ) as! EnrollmentViewController
                self.navigationController?.pushViewController(vc, animated: true)
            }else if indexPath.row == 2{
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "AttendenceViewController" ) as! AttendenceViewController
                self.navigationController?.pushViewController(vc, animated: true)
            }else if indexPath.row == 3{
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "StatusViewController" ) as! StatusViewController
                self.navigationController?.pushViewController(vc, animated: true)
            }else if indexPath.row == 4{
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "ProfileEditViewController" ) as! ProfileEditViewController
                self.navigationController?.pushViewController(vc, animated: true)
            }else if indexPath.row == 5{
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "AllLoginPageViewController" ) as! AllLoginPageViewController
                self.navigationController?.pushViewController(vc, animated: true)
            }
            } else if conditionCheck == "Faculty"{
                
                if indexPath.row == 0 {
                    
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "CalenderViewController" ) as! CalenderViewController
                    self.navigationController?.pushViewController(vc, animated: true)
                }else if indexPath.row == 1{
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "FacultyRegistrationViewController" ) as! FacultyRegistrationViewController
                    self.navigationController?.pushViewController(vc, animated: true)
                }else if indexPath.row == 2{
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "FacultyAttendenceViewController" ) as! FacultyAttendenceViewController
                    self.navigationController?.pushViewController(vc, animated: true)
                }else if indexPath.row == 3{
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "AttendenceDetailsViewController" ) as! AttendenceDetailsViewController
                    self.navigationController?.pushViewController(vc, animated: true)
                }else if indexPath.row == 4{
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "FacultyLaunchCourseViewController" ) as! FacultyLaunchCourseViewController
                    self.navigationController?.pushViewController(vc, animated: true)
                }else if indexPath.row == 5{
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "ProfileEditViewController" ) as! ProfileEditViewController
                    self.navigationController?.pushViewController(vc, animated: true)
                }else if indexPath.row == 6{
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "AllLoginPageViewController" ) as! AllLoginPageViewController
                    self.navigationController?.pushViewController(vc, animated: true)
                }
            }else if conditionCheck == "Admin"{
                
                if indexPath.row == 0 {
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "CalenderViewController" ) as! CalenderViewController
                    self.navigationController?.pushViewController(vc, animated: true)
                }else if indexPath.row == 1{
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "ManageStudentsViewController" ) as! ManageStudentsViewController
                    vc.titleText = "Manage Students"
                    self.navigationController?.pushViewController(vc, animated: true)
                }else if indexPath.row == 2{
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "ManageStudentsViewController" ) as! ManageStudentsViewController
                    vc.titleText = "Manage Faculties"
                    self.navigationController?.pushViewController(vc, animated: true)
                }else if indexPath.row == 3{
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "EventsViewController" ) as! EventsViewController
                    self.navigationController?.pushViewController(vc, animated: true)
                }else if indexPath.row == 4{
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "AllLoginPageViewController" ) as! AllLoginPageViewController
                    self.navigationController?.pushViewController(vc, animated: true)
                }
            }
        }
    }
    class MenuTableViewCell : UITableViewCell{
        
        @IBOutlet weak var View: UIView!
        @IBOutlet weak var Label: UILabel!
        @IBOutlet weak var menuImage : UIImageView!
        
    }


    

