//
//  PushView.swift
//  MediquizPro
//
//  Created by SAIL on 15/09/23.
//

import Foundation
import UIKit


class PushView {
    
    
    static var shared: PushView = PushView()
    
    init(){}
    
    func pushToView(storyBoard: String, identifier: String, controller: UIViewController) {
        let vc = UIStoryboard.init(name: storyBoard, bundle: nil).instantiateViewController(withIdentifier: identifier)
       // self.navigationController?.pushViewController(vc, animated: true)
    }
}
