//
//  QuestionVC.swift
//  sampleApp
//
//  Created by SAIL on 15/09/23.
//

import UIKit

class QuestionVC: UIViewController {
    
    @IBOutlet weak var questionList: UITableView!
    
    
    var answerArray = ["Fistula", "Atresia", "Stenosis", "Varices"]
    
   
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.questionList.delegate = self
        self.questionList.dataSource = self

    }

}

extension QuestionVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return answerArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "QACell", for: indexPath) as! QACell
        cell.questionLblText.text = answerArray[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 40
    }
    
}
