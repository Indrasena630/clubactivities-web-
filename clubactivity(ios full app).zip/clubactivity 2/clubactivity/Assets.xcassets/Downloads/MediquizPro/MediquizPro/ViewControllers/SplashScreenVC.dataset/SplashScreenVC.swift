//
//  SplashScreenVC.swift
//  MediquizPro
//
//  Created by SAIL on 15/09/23.
//

import UIKit

class SplashScreenVC: ViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        DispatchQueue.main.async {
            let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "InitialViewController") as! InitialViewController
            self.navigationController?.pushViewController(nextVC, animated: true)
            
            
        }
    }
}
