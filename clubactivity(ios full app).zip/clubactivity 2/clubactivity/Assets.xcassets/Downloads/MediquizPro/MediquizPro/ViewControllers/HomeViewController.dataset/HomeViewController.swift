//
//  ViewController.swift
//  sampleApp
//
//  Created by SAIL on 15/09/23.
//

import UIKit

class HomeViewController: UIViewController {
    
    
    @IBOutlet weak var pathologyView: UIView!
    @IBOutlet weak var headNeckView: UIView!
    @IBOutlet weak var respiratoryView: UIView!
    @IBOutlet weak var cardioView: UIView!
    @IBOutlet weak var throatView: UIView!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(self.pathologyQA(_:)))
        headNeckView.addGestureRecognizer(tap)
        headNeckView.isUserInteractionEnabled = true
        self.view.addSubview(pathologyView)
        
    }
    
    @objc func pathologyQA(_ sender: UITapGestureRecognizer? = nil) {
        let vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "QuestionVC") as! QuestionVC
        self.navigationController?.pushViewController(vc, animated: true)
       
    }


}

