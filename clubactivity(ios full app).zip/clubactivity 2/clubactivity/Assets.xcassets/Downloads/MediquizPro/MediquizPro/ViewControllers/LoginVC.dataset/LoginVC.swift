

import UIKit

class LoginVC: ViewController {

    @IBOutlet weak var forgot: UIView!
    @IBOutlet weak var login: UIButton!
    @IBOutlet weak var signup: UIButton!
   
    @IBOutlet weak var forgotpassword: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()

    
    }
    
    
    @IBAction func onlogin(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "HomeViewController")
        as! HomeViewController
        self.navigationController?.pushViewController(vc, animated:true)
        
    }
    
    
    @IBAction func omsignup(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "SignInVC")
        as! SignInVC
        self.navigationController?.pushViewController(vc, animated:true)
        
    }
    
    @IBAction func onforgot(_ sender: Any){
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "ForgotPasswordVC")
        as! ForgotPasswordVC
        self.navigationController?.pushViewController(vc, animated:true)
    }
}
