//
//  InitialViewController.swift
//  MediquizPro
//
//  Created by SAIL on 15/09/23.
//

import UIKit

class InitialViewController: ViewController {

    @IBOutlet weak var doctorlogin: UIButton!
    
    @IBOutlet weak var studentlogin: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        doctorlogin.layer.cornerRadius=20
        doctorlogin.clipsToBounds=true
        
        studentlogin.layer.cornerRadius = 20
        studentlogin.clipsToBounds = true
        
    }
    
    
    @IBAction func onstudent(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "LoginVC")
        as! LoginVC
        self.navigationController?.pushViewController(vc, animated:true)
      
    }
    
    
}
