

import UIKit

class SignInVC: ViewController {

    @IBOutlet weak var create: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    @IBAction func oncreate(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "HomeViewController")
        as! HomeViewController
        self.navigationController?.pushViewController(vc, animated:true)
    }
    
 

}
