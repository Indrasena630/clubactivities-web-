
import UIKit

class ForgotPasswordVC: ViewController {

    @IBOutlet weak var save: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    

  
    @IBAction func onsave(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "LoginVC")
        as! LoginVC
        self.navigationController?.pushViewController(vc, animated:true)
    }
}
