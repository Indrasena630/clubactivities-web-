//
//  StudentLogin.swift
//  mcq
//
//  Created by SAIL on 12/09/23.
//

import UIKit

class StudentLogin: UIViewController {

    @IBOutlet weak var login: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    
    @IBAction func onlogin(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "StudentHome")
        as! StudentHome
        self.navigationController?.pushViewController(vc, animated:true)
    }
    
}
