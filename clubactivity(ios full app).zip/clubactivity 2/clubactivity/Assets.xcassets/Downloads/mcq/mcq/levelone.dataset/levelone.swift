//
//  levelone.swift
//  mcq
//
//  Created by SAIL on 14/09/23.
//

import UIKit

class levelone: UIViewController {

    @IBOutlet weak var start: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    

    @IBAction func onStart(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "mcqpage")
        as! mcqpage
        self.navigationController?.pushViewController(vc, animated:true)
    }

    

}
