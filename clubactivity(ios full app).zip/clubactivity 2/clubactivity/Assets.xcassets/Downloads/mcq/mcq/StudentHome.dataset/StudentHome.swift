

import UIKit

class StudentHome: UIViewController {

    @IBOutlet weak var topic1: UIButton!
    @IBOutlet weak var topic2: UIButton!
    @IBOutlet weak var topic3: UIButton!
    @IBOutlet weak var topic4: UIButton!
    @IBOutlet weak var topic5: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        topic1.layer.cornerRadius = 20
        topic2.layer.cornerRadius = 20
        topic3.layer.cornerRadius = 20
        topic4.layer.cornerRadius = 20
        topic5.layer.cornerRadius = 20
      
    }
    
    @IBAction func onPathology(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "levelone")
        as! levelone
        self.navigationController?.pushViewController(vc, animated:true)
    }
    
}
