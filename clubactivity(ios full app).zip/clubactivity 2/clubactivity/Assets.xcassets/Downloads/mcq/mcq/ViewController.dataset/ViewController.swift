//
//  ViewController.swift
//  mcq
//
//  Created by SAIL on 12/09/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var logoview: UIImageView!
    
    @IBOutlet weak var Apptitle: UILabel!
    
    @IBOutlet weak var doctorlogin: UIButton!
    
    @IBOutlet weak var studentlogin: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        doctorlogin.layer.cornerRadius=20
        doctorlogin.clipsToBounds=true
        
        studentlogin.layer.cornerRadius = 20
        studentlogin.clipsToBounds = true
    }
    @IBAction func onStudent(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "StudentLogin")
        as! StudentLogin
        self.navigationController?.pushViewController(vc, animated:true)
      
        
    }
    @IBAction func onDoctor(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "DoctorLogin")
        as! DoctorLogin
        self.navigationController?.pushViewController(vc, animated:true)
        
        
    }
    
}

