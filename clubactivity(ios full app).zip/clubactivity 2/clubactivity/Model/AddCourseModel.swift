//
//  AddCourseModel.swift
//  clubactivity
//
//  Created by SAIL on 19/10/23.
//

import Foundation

// MARK: - Welcome
struct AddCourseModel: Codable {
    let status: Bool
    let message: String
}
