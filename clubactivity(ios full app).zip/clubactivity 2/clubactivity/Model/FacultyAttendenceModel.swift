//
//  FacultyAttendenceModel.swift
//  clubactivity
//
//  Created by SAIL on 26/10/23.
//

import Foundation


// MARK: - Welcome
struct FacultyAttendenceModel: Codable {
    let status: Bool
    let message: String
    let data: [datum]
}

// MARK: - Datum
struct datum: Codable {
    let studentID, name: String

    enum CodingKeys: String, CodingKey {
        case studentID = "StudentId"
        case name = "Name"
    }
}

struct FacultyAttendencePostModel: Codable {
    let status: Bool
    let message: String
}




