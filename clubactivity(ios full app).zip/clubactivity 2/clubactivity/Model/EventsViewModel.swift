//
//  EventsViewModel.swift
//  clubactivity
//
//  Created by SAIL on 19/10/23.
//

import Foundation
// MARK: - Welcome
struct EventsViewModel: Codable {
    let courses: [Course]
    let status: Bool
    let message: String
}

// MARK: - Course
struct Course: Codable {
    let coursename, courseid, facultyid, strength: String
    let coursestatus: String
}
