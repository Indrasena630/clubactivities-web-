//
//  EnrollmentViewModel.swift
//  clubactivity
//
//  Created by SAIL on 25/10/23.
//

import Foundation
import CoreImage


struct EnrollmentViewModel: Codable {
    let courses: [coursedatas]
    let status: Bool
    let message: String
}

// MARK: - Course
struct coursedatas: Codable {
    let courseName, courseID, strength: String

    enum CodingKeys: String, CodingKey {
        case courseName = "CourseName"
        case courseID = "CourseId"
        case strength = "Strength"
    }
}

// MARK: - EnrollmentPostModel
struct EnrollmentPostModel: Codable {
    let status: Bool
    let message: String
}


