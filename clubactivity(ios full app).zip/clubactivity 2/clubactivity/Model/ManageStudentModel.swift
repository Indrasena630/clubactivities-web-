//
//  ManageStudentModel.swift
//  clubactivity
//
//  Created by SAIL on 18/10/23.
//

import Foundation

// MARK: - Welcome
struct ManageStudentModel: Codable {
    let students: [Student]
    let success: Bool
    let message: String
}

// MARK: - Student
struct Student: Codable {
    let name, studentid, password, contact: String
    let address, dob, email: String
}
