//
//  FacultyattendenceselectModel.swift
//  clubactivity
//
//  Created by SAIL on 30/11/23.
//

import Foundation

// MARK: - Welcome
struct FacultyattendenceselectModel: Codable {
    let status: Bool
    let message : String
    let courses: [course]
}

// MARK: - Course
struct course: Codable {
    let courseID, courseName: String

    enum CodingKeys: String, CodingKey {
        case courseID = "courseId"
        case courseName
    }
}
