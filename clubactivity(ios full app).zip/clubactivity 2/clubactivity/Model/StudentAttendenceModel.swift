//
//  StudentAttendenceModel.swift
//  clubactivity
//
//  Created by SAIL on 24/10/23.
//

import Foundation
// MARK: - Welcome
struct StudentAttendenceModel: Codable {
    let coursedata: [Coursedatum]
    let status: Bool
    let message: String
}

// MARK: - Coursedatum
struct Coursedatum: Codable {
    let clubName, clubCode, classesAttended, totalClasses: String
    let percentage: Float

    enum CodingKeys: String, CodingKey {
        case clubName = "ClubName"
        case clubCode = "ClubCode"
        case classesAttended = "ClassesAttended"
        case totalClasses = "TotalClasses"
        case percentage = "Percentage"
    }
}
