//
//  FacultyProfileEditModel.swift
//  clubactivity
//
//  Created by SAIL on 26/10/23.
//

import Foundation

// MARK: - Welcome
struct FacultyProfileEditModel: Codable {
    let status: Bool
    let message: String
    let data: FacultyProfileEdit
}

// MARK: - DataClass
struct FacultyProfileEdit: Codable {
    let name, facultyid, password, contact: String
    let address, dob, email: String
}
