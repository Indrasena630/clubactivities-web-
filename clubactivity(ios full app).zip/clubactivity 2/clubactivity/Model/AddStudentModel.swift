//
//  AddStudentModel.swift
//  clubactivity
//
//  Created by SAIL on 18/10/23.
//

import Foundation
// MARK: - Welcome
struct AddStudentModel: Codable {
    let status: Bool
    let message: String
}
