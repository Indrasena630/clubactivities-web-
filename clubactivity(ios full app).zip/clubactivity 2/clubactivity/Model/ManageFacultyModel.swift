//
//  ManageFacultyModel.swift
//  clubactivity
//
//  Created by SAIL on 19/10/23.
//

import Foundation

// MARK: - Welcome
struct ManageFacultyModel: Codable {
    let facultyMembers: [FacultyMember]
    let status: Bool
    let message: String
}

// MARK: - FacultyMember
struct FacultyMember: Codable {
    let name, facultyid, password, contact: String
    let address, dob, email: String
}
