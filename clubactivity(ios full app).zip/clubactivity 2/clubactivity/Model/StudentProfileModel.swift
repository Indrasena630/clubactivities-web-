//
//  StudentProfileModel.swift
//  clubactivity
//
//  Created by SAIL on 24/10/23.
//

import Foundation

// MARK: - Welcome
struct StudentProfileModel: Codable {
    let status: Bool
    let message: String
    let data: profile
}

// MARK: - DataClass
// MARK: - DataClass

struct profile: Codable {
    let name, studentid, password, contact: String
    let address, dob, email: String
}
