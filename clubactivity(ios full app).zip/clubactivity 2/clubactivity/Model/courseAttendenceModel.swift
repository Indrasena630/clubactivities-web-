//
//  courseAttendenceModel.swift
//  clubactivity
//
//  Created by SAIL on 30/11/23.
//

import Foundation


// MARK: - Welcome
struct courseAttendenceModel: Codable {
    let status: Bool
    let message: String
    let data: [courseAttendenceData]
}

// MARK: - Datum
struct courseAttendenceData: Codable {
    let studentID, name, attendedClasses, totalClasses: String
    let percentage: Int

    enum CodingKeys: String, CodingKey {
        case studentID = "StudentId"
        case name = "Name"
        case attendedClasses = "Attended Classes"
        case totalClasses = "Total Classes"
        case percentage = "Percentage"
    }
}
