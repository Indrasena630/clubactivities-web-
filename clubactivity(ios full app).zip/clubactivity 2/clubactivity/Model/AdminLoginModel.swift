//
//  AdminLoginModel.swift
//  clubactivity
//
//  Created by SAIL on 18/10/23.
//

import Foundation

struct AdminLoginModel : Codable {
    let status: Bool
    let message: String
    let data: adminData
}


struct adminData : Codable {
    let username, password: String

    enum CodingKeys: String, CodingKey {
        case username
        case password = "Password"
    }
}


struct studentLoginModel: Codable {
    let status: Bool
    let message: String
    let data: studentData
}


struct studentData: Codable {
    let name, studentid, password, contact: String
    let address, dob, email: String
}

struct facultyLoginModel: Codable {
    let status: Bool
    let message: String
    let data: facultyData
}


struct facultyData: Codable {
    let name, facultyid, password, contact: String
    let address, dob, email: String
}
