//
//  StudentEditProfileModel.swift
//  clubactivity
//
//  Created by SAIL on 24/10/23.
//

import Foundation

// MARK: - Welcome
struct StudentEditProfileModel: Codable {
    let success: Bool
    let message: String
}
