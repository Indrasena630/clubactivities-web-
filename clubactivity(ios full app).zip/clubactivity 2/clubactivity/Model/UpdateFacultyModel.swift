//
//  UpdateFacultyModel.swift
//  clubactivity
//
//  Created by SAIL on 30/10/23.
//

import Foundation

struct UpdateFacultyModel: Codable {
    let status: Bool
    let message: String
}
