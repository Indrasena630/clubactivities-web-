//
//  FacultyLaunchCourseModel.swift
//  clubactivity
//
//  Created by SAIL on 26/10/23.
//

import Foundation

// MARK: - Welcome
struct FacultyLaunchCourseModel: Codable {
    let status: Bool
    let message: String
    let data: [studentdetails]
}

// MARK: - Datum
struct studentdetails: Codable {
    let studentID, name: String

    enum CodingKeys: String, CodingKey {
        case studentID = "StudentId"
        case name = "Name"
    }
}


struct FacultyLaunchCoursePostModel: Codable {
    let status: Bool
    let message: String
}
