//
//  FacultyRegistrationModel.swift
//  clubactivity
//
//  Created by SAIL on 26/10/23.
//

import Foundation

struct FacultyRegistrationModel : Codable {
    let status : Bool?
    let message : String?
    let data : [FacultyRegistration]?

    enum CodingKeys: String, CodingKey {

        case status = "status"
        case message = "message"
        case data = "data"
    }
}
struct FacultyRegistration : Codable {
    let courseId : String?
    let studentId : String?
    let name : String?
    let status : String?

    enum CodingKeys: String, CodingKey {

        case courseId = "courseId"
        case studentId = "StudentId"
        case name = "Name"
        case status = "Status"
    }
}

struct FacultyRegistrationPostModel: Codable {
    let success: Bool
    let message: String
}
struct FacultyRejectPostModel: Codable {
    let status: Bool
    let message: String
}
