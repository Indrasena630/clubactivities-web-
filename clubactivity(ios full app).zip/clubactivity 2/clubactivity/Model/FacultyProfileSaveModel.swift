//
//  FacultyProfileSaveModel.swift
//  clubactivity
//
//  Created by SAIL on 26/10/23.
//

import Foundation

// MARK: - Welcome
struct FacultyProfileSaveModel: Codable {
    let success: Bool
    let message: String
}
