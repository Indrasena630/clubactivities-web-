//
//  StudentLoginModel.swift
//  clubactivity
//
//  Created by SAIL on 16/10/23.
//

import Foundation

// MARK:-Welcome
struct StudentLoginModel:Codable{
  
        let status:Bool
        let message:String
        let data:DataClass
    }
    //MARK:-DataClass
    struct DataClass: Codable{
        let name,Studentid,password,contact:String
    }
