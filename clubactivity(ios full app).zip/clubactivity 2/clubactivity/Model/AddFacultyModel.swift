//
//  AddFacultyModel.swift
//  clubactivity
//
//  Created by SAIL on 30/10/23.
//

import Foundation
// MARK: - Welcome
struct AddFacultyModel: Codable {
    let status: Bool
    let message: String
}


