//
//  ChangeFacultyPasswordModel.swift
//  clubactivity
//
//  Created by SAIL on 30/10/23.
//

import Foundation

// MARK: - Welcome
struct ChangeFacultyPasswordModel: Codable {
    let status: Bool
    let message: String
}

