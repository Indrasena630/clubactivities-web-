//
//  courseListModel.swift
//  clubactivity
//
//  Created by SAIL on 30/11/23.
//

import Foundation

// MARK: - Welcome
struct courseListModel: Codable {
    let status: Bool
    let message: String
    let courses: [courses]
}

// MARK: - Course
struct courses: Codable {
    let courseID, courseName: String

    enum CodingKeys: String, CodingKey {
        case courseID = "courseId"
        case courseName
    }
}
