//
//  StatusModel.swift
//  clubactivity
//
//  Created by SAIL on 24/10/23.
//

import Foundation

struct StudentStatusModel: Codable {
    let coursedata: [studentStatus]
    let status: Bool
    let message: String
}

// MARK: - studentStatus
struct studentStatus: Codable {
    let clubName, clubCode, status, feedback: String

    enum CodingKeys: String, CodingKey {
        case clubName = "ClubName"
        case clubCode = "ClubCode"
        case status = "Status"
        case feedback = "Feedback"
    }
}
