//
//  UpdateStudentViewController.swift
//  clubactivity
//
//  Created by SAIL on 11/10/23.
//

import UIKit

class UpdateStudentViewController: BasicViewController {
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var NameTextField: UITextField!
    @IBOutlet weak var contactTextField: UITextField!
    @IBOutlet weak var addressTextField: UITextField!
    @IBOutlet weak var updateButton: UIButton!
    
    var updateStudents : UpdateStudentModel!
    var updateFaculty : UpdateFacultyModel!
    
    var titleName = ""
    var studentName: String?
    var studentID: String?

    override func viewDidLoad() {
        super.viewDidLoad()
        print(titleName)
        if titleName == "Manage Students"{
            titleLabel.text = "Update Student"
        }else if titleName == "Manage Faculties"{
            titleLabel.text = "Update Faculty"
            updateButton.setTitle("Update Faculty", for: .normal)
        }

        print("------>",studentName ?? "" ,studentID ?? "")
    
    }
    
    
    @IBAction func updateStudentButtonAction(_ sender: UIButton) {
        
        if NameTextField.text?.isEmpty == true{
            showToast("Enter the Name")
        }else if contactTextField.text?.isEmpty == true{
            showToast("Enter the Contact NO.")
        }else if addressTextField.text?.isEmpty == true{
            showToast("Enter the Address")
        }else{
            if !isValidPhone(testStr: contactTextField.text ?? "Empty"){
                showToast("Enter the Valid Contact Number")
            }else{
                self.getAPI()
            }
        }
    }
    
    @IBAction func backButton(_ sender: UIButton) {
        
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func menuButton(_ sender: UIButton) {
        
        
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "MenuViewController") as! MenuViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    

   }

extension UpdateStudentViewController{

    func getAPI(){
        if titleLabel.text == "Update Student"{
            self.startIndicator()
            let apiURL = APIList().urlString(url:.UpdateStudent)
            let formData = ["name":"\(NameTextField.text ?? "Error")",
                            "studentid":"\(studentID ?? "Error")",
                       "contact":"\(contactTextField.text ?? "Error")",
                       "address":"\(addressTextField.text ?? "Error")"]

            APIHandler().postAPIValues(type: UpdateStudentModel.self, apiUrl: apiURL, method: "POST", formData: formData) {  result in
                   switch result {
                   case .success(let data):
                       self.updateStudents = data
                     print(data)
                       if self.updateStudents.status == true{
                           DispatchQueue.main.async { [self] in
                               self.stopIndicator()
                               showToast(self.updateStudents.message)
                               self.navigationController?.popViewController(animated: true)
                              
                          }
                       }
                       else if self.updateStudents.status == false{
                           DispatchQueue.main.async {
                               self.showToast(self.updateFaculty.message)
                               self.stopIndicator()
                           }
                       }
                       case .failure(let error):
                       print(error)
                       DispatchQueue.main.async {
                           self.stopIndicator()
                       let alert = UIAlertController(title: "Warning", message: "Something Went Error", preferredStyle: .alert)
                       alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { ok in
                           print("JSON Error")
                       })
                       self.present(alert, animated: true, completion: nil)
                       }
                   }
               }
            
        } else if titleLabel.text == "Update Faculty"{
            self.startIndicator()
            let apiURL = APIList().urlString(url:.UpdateFaculty)
            let formData = ["name":"\(NameTextField.text ?? "Error")",
                            "facultyid":"\(studentID ?? "Error")",
                       "contact":"\(contactTextField.text ?? "Error")",
                       "address":"\(addressTextField.text ?? "Error")"]

            APIHandler().postAPIValues(type: UpdateFacultyModel.self, apiUrl: apiURL, method: "POST", formData: formData) {  result in
                   switch result {
                   case .success(let data):
                       self.updateFaculty = data
                     print(data)
                       if self.updateFaculty.status == true{
                           DispatchQueue.main.async { [self] in
                               self.stopIndicator()
                               showToast(self.updateFaculty.message)
                               self.navigationController?.popViewController(animated: true)
                              
                          }
                       }
                       else if self.updateFaculty.status == false{
                           DispatchQueue.main.async {
                               self.showToast(self.updateFaculty.message)
                               self.stopIndicator()
                           }
                           
                       }
                       case .failure(let error):
                       print(error)
                       DispatchQueue.main.async {
                           self.stopIndicator()
                       let alert = UIAlertController(title: "Warning", message: "Something Went Error", preferredStyle: .alert)
                       alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { ok in
                           print("JSON Error")
                       })
                       self.present(alert, animated: true, completion: nil)
                       }
                   }
               }
        }
            
        }
    
}
    
      
