//
//  ManageStudentsViewController.swift
//  clubactivity
//
//  Created by SAIL on 11/10/23.
//

import UIKit

class ManageStudentsViewController: BasicViewController {

    @IBOutlet weak var manageStudentsTableView: UITableView!
    @IBOutlet weak var titleLabel : UILabel!
    @IBOutlet weak var addButton : UIButton!
    
    var titleText = ""
    var manageFaculty :  ManageFacultyModel!
    var manageStudents : ManageStudentModel!
    var updateStudents : UpdateStudentModel!
    var contentString = ["Update Student","Change Password","InActive"]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.titleLabel.text = titleText
        if titleText == "Manage Faculties"{
            contentString = ["Update Faculty","Change Password","InActive"]
        }
        
        GetAPI()
        
    }
    override func viewWillAppear(_ animated: Bool) {
        self.GetAPI()
        self.manageStudentsTableView.reloadData()
    }
    
   
  // MARK: Actions
    
    @objc func connected(sender: UIButton) {
        if let indexPath = manageStudentsTableView.indexPathForRow(at: sender.convert(sender.bounds.origin, to: manageStudentsTableView)) {
            if titleText == "Manage Students"{
                let selectedStudent = manageStudents?.students[indexPath.row]
                let name = selectedStudent?.name
                let studentID = selectedStudent?.studentid

                let actionSheet = UIAlertController(title: "Select Action", message: nil, preferredStyle: .actionSheet)
                let updateAction = UIAlertAction(title: "Update Student", style: .default) { _ in
                    self.updateStudent(name: name, studentID: studentID)
                }
                let changePasswordAction = UIAlertAction(title: "Change Password", style: .default) { _ in
                    self.changePassword(name: name, studentID: studentID)
                }
                let deleteAction = UIAlertAction(title: "InActive", style: .destructive) { _ in
                    self.InActive(name: name, studentID: studentID)
                }
                let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
                actionSheet.addAction(updateAction)
                actionSheet.addAction(changePasswordAction)
                actionSheet.addAction(deleteAction)
                actionSheet.addAction(cancelAction)
                present(actionSheet, animated: true, completion: nil)
            }else if titleText == "Manage Faculties"{
                let selectedFaculty = manageFaculty?.facultyMembers[indexPath.row]
                let name = selectedFaculty?.name
                let facultyID = selectedFaculty?.facultyid
                
                let actionSheet = UIAlertController(title: "Select Action", message: nil, preferredStyle: .actionSheet)
                let updateAction = UIAlertAction(title: "Update Faculty", style: .default) { _ in
                    self.updateStudent(name: name, studentID: facultyID)
                }
                let changePasswordAction = UIAlertAction(title: "Change Password", style: .default) { _ in
                    self.changePassword(name: name, studentID: facultyID)
                }
                let deleteAction = UIAlertAction(title: "InActive", style: .destructive) { _ in
                    self.InActive(name: name, studentID: facultyID)
                }
                let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
                actionSheet.addAction(updateAction)
                actionSheet.addAction(changePasswordAction)
                actionSheet.addAction(deleteAction)
                actionSheet.addAction(cancelAction)
                present(actionSheet, animated: true, completion: nil)
            }
    }
            
    }

    func updateStudent(name: String?, studentID: String?) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "UpdateStudentViewController") as! UpdateStudentViewController
        vc.titleName = titleText
        vc.studentName = name
        vc.studentID = studentID
        self.navigationController?.pushViewController(vc, animated: true)
    }

    func changePassword(name: String?, studentID: String?) {
        
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ChangePasswordViewController") as! ChangePasswordViewController
        vc.titleName = titleText
        vc.studentName = name
        vc.studentID = studentID
        self.navigationController?.pushViewController(vc, animated: true)
    }

    func InActive(name: String?, studentID: String?) {
        
        let alertController = UIAlertController(title: "Confirm", message: "Are you sure you want to Deactivate this \(name ?? "")", preferredStyle: .alert)
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        let deleteAction = UIAlertAction(title: "Ok", style: .destructive) { [weak self] _ in
            self?.InActiveApi(Id: studentID ?? "")
        }
        alertController.addAction(cancelAction)
        alertController.addAction(deleteAction)
        present(alertController, animated: true, completion: nil)
    }


    @IBAction func backButton(_ sender: UIButton) {
        
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func addStudentsButton(_ sender: UIButton) {
        
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "AddStudentViewController") as! AddStudentViewController
        vc.titleName = addButton.currentTitle ?? ""
        self.navigationController?.pushViewController(vc, animated: true)
    }
   
    @IBAction func menuButton(_ sender: UIButton) {
        
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "MenuViewController") as! MenuViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
}

 // MARK: Api Integration

extension ManageStudentsViewController{
    
   
    func GetAPI(){
        var apiURL = ""
        
        if (self.titleLabel.text == "Manage Students"){
            
         apiURL = APIList().urlString(url:.ManageStudent)
           APIHandler().getAPIValues(type: ManageStudentModel.self, apiUrl: apiURL, method: "GET") {  result in
               switch result {
               case .success(let data):
                   self.manageStudents = data
                 print(data)
                   DispatchQueue.main.async {
                   if self.manageStudents.success == true{
                       
                           self.addButton.setTitle("Add Student", for: .normal)
                           self.manageStudentsTableView.reloadData()
                      
                   }
                   else if self.manageStudents.success == false{
                       self.showToast(self.manageStudents.message)
                   }
                   }
                   case .failure(let error):
                   print(error)
                   DispatchQueue.main.async {
                   let alert = UIAlertController(title: "OOPS", message: "Something Went Wrong", preferredStyle: .alert)
                   alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { ok in
                       print("JSON Error")
                   })
                   self.present(alert, animated: true, completion: nil)
                   }
               }
           }
        }else if self.titleLabel.text == "Manage Faculties" {
            self.startIndicator()
            apiURL = APIList().urlString(url:.ManageFaculty)
            
              APIHandler().getAPIValues(type: ManageFacultyModel.self, apiUrl: apiURL, method: "GET") {  result in
                  switch result {
                  case .success(let data):
                      self.manageFaculty = data
                    print(data)
                      if self.manageFaculty.status == true{
                          DispatchQueue.main.async {
                              self.stopIndicator()
                              self.addButton.setTitle("Add Faculty", for: .normal)
                              self.manageStudentsTableView.reloadData()
                         }
                      }
                      else if self.manageFaculty.status == false{
                          DispatchQueue.main.async {
                              self.stopIndicator()
                              self.showToast(self.manageFaculty.message)
                          }
                      }
                      case .failure(let error):
                      print(error)
                      DispatchQueue.main.async {
                      let alert = UIAlertController(title: "Warning", message: "Something Went Error", preferredStyle: .alert)
                      alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { ok in
                          print("JSON Error")
                      })
                      self.present(alert, animated: true, completion: nil)
                      }
                  }
              }
        }
    }
    func InActiveApi(Id: String){
        if titleLabel.text == "Manage Students"{
            self.startIndicator()
            let apiURL = APIList().urlString(url:.DeleteStudent)
            let formData = ["userid":"\(Id)"]
            print(apiURL,formData)

            APIHandler().postAPIValues(type: UpdateStudentModel.self, apiUrl: apiURL, method: "POST", formData: formData) {  result in
                   switch result {
                   case .success(let data):
                       self.updateStudents = data
                     print(data)
                       if self.updateStudents.status == true{
                           DispatchQueue.main.async { [self] in
                               self.stopIndicator()
                               showToast(self.updateStudents.message)
                               self.GetAPI()
                               self.manageStudentsTableView.reloadData()
                          }
                       }
                       else if self.updateStudents.status == false{
                           DispatchQueue.main.async {
                           self.showToast(self.updateStudents.message)
                           self.stopIndicator()
                           }
                       }
                       case .failure(let error):
                       print(error)
                       DispatchQueue.main.async {
                           self.stopIndicator()
                       let alert = UIAlertController(title: "Warning", message: "Something Went Error", preferredStyle: .alert)
                       alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { ok in
                           print("JSON Error")
                       })
                       self.present(alert, animated: true, completion: nil)
                       }
                   }
               }
        } else if self.titleLabel.text == "Manage Faculties"{
            self.startIndicator()
            let apiURL = APIList().urlString(url:.DeleteFaculty)
            let formData = ["userid":"\(Id)"]
            print(apiURL,formData)

            APIHandler().postAPIValues(type: UpdateStudentModel.self, apiUrl: apiURL, method: "POST", formData: formData) {  result in
                   switch result {
                   case .success(let data):
                       self.updateStudents = data
                     print(data)
                       if self.updateStudents.status == true{
                           DispatchQueue.main.async { [self] in
                               self.stopIndicator()
                               showToast(self.updateStudents.message)
                               self.GetAPI()
                               self.manageStudentsTableView.reloadData()
                          }
                       }
                       else if self.updateStudents.status == false{
                           DispatchQueue.main.async {
                           self.showToast(self.updateStudents.message)
                           self.stopIndicator()
                           }
                       }
                       case .failure(let error):
                       print(error)
                       DispatchQueue.main.async {
                           self.stopIndicator()
                       let alert = UIAlertController(title: "Warning", message: "Something Went Error", preferredStyle: .alert)
                       alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { ok in
                           print("JSON Error")
                       })
                       self.present(alert, animated: true, completion: nil)
                       }
                   }
               }
        }
    }
    
}
   
// MARK: TableView Function

extension ManageStudentsViewController : UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if (self.titleLabel.text == "Manage Students"){
        return manageStudents?.students.count ?? 1
        }else {
            return manageFaculty?.facultyMembers.count ?? 1
        }
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell =  tableView.dequeueReusableCell(withIdentifier: "manageStudentsCell") as! manageStudentsCell
        
        cell.backgroundColor = UIColor.white
        cell.View.layer.borderColor = UIColor.black.cgColor
        cell.View.layer.borderWidth = 1
        cell.View.layer.cornerRadius = 8
        cell.View.clipsToBounds = true
        
        if (self.titleLabel.text == "Manage Students"){
        
        cell.nameLabel.text = manageStudents?.students[indexPath.row].name
        cell.studentIdLabel.text = manageStudents?.students[indexPath.row].studentid
        cell.AttendanceButton.tag = indexPath.row
        cell.AttendanceButton.addTarget(self, action: #selector(connected(sender:)), for: .touchUpInside)
        
        }
        else{
            cell.nameLabel.text = manageFaculty?.facultyMembers[indexPath.row].name
            cell.studentIdLabel.text = manageFaculty?.facultyMembers[indexPath.row].facultyid
            cell.studentLabelName.text = "Faculty Id :"
            cell.AttendanceButton.tag = indexPath.row
            cell.AttendanceButton.addTarget(self, action: #selector(connected(sender:)), for: .touchUpInside)
        }
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 150
    }
   
    
}
class manageStudentsCell : UITableViewCell{
    
    @IBOutlet weak var View: UIView!
    
    @IBOutlet weak var nameLabel: UILabel!
    
    @IBOutlet weak var studentIdLabel: UILabel!
    @IBOutlet weak var studentLabelName: UILabel!
    
    @IBOutlet weak var AttendanceButton: UIButton!
    
}









