//
//  AddCourseViewController.swift
//  clubactivity
//
//  Created by SAIL on 11/10/23.
//

import UIKit

class AddCourseViewController: BasicViewController {
    
    var addCourse : AddCourseModel!
    
    @IBOutlet weak var clubCodeTextField: UITextField!
    
    @IBOutlet weak var clubNameTextField: UITextField!
    
    @IBOutlet weak var facultyIdTextField: UITextField!
    
    @IBOutlet weak var strengthTextField: UITextField!
   
    @IBOutlet weak var addCourseButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        }
   
    
    @IBAction func backButton(_ sender: UIButton) {
        
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func menuButton(_ sender: UIButton) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "MenuViewController") as! MenuViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    func GetAPI(){
        self.startIndicator()
        let apiURL = APIList().urlString(url:.AddCourse)
        let formData = ["eventid":"\(clubCodeTextField.text ?? "Error")",
                   "eventname":"\(clubNameTextField.text ?? "Error")",
                   "sirno":"\(facultyIdTextField.text ?? "Error")",
                   "totalno":"\(strengthTextField.text ?? "Error")"]
    
        APIHandler().postAPIValues(type: AddCourseModel.self, apiUrl: apiURL, method: "POST", formData: formData) {  result in
               switch result {
               case .success(let data):
                   self.addCourse = data
                 print(data)
                   if self.addCourse.status == true{
                       DispatchQueue.main.async { [self] in
                           self.stopIndicator()
                           showToast(self.addCourse.message)
                           self.navigationController?.popViewController(animated: true)
                           if let lastViewController = self.navigationController?.viewControllers.last as? EventsViewController {
                               lastViewController.eventsTableView.reloadData()
                           }
                      }
                   }
                   else if self.addCourse.status == false{
                   }
                   case .failure(let error):
                   print(error)
                   DispatchQueue.main.async {

                   let alert = UIAlertController(title: "Warning", message: "Something Went Error", preferredStyle: .alert)
                   alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { ok in
                       print("JSON Error")
                   })
                   self.present(alert, animated: true, completion: nil)
                   }
               }
           }
    }
    
    @IBAction func addButton(_ sender: UIButton) {
        
        if clubCodeTextField.text?.isEmpty == true{
            showToast("Enter the clubcode")
        }else if clubNameTextField.text?.isEmpty == true{
            showToast("Enter the clubname")
        }else if facultyIdTextField.text?.isEmpty == true{
            showToast("Enter the facultyid")
        }else if strengthTextField.text?.isEmpty == true{
           showToast("Enter the strength")
        } else {
            GetAPI()
            }
       
    }
    

   

}
