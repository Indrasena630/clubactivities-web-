//
//  AddStudentViewController.swift
//  clubactivity
//
//  Created by SAIL on 09/10/23.
//

import UIKit

class AddStudentViewController: BasicViewController {
    
    var addStudents : AddStudentModel!
    var addFaculty  : AddFacultyModel!
    
    @IBOutlet weak var titleLabel : UILabel!
    @IBOutlet weak var facultyIdLabel: UILabel!
    @IBOutlet weak var addButton : UIButton!
    
    @IBOutlet weak var NameTextField: UITextField!
    @IBOutlet weak var StudentidTextField: UITextField!
    @IBOutlet weak var PasswordTextField: UITextField!
    @IBOutlet weak var ContactTextField: UITextField!
    @IBOutlet weak var AddressTextField: UITextField!
    @IBOutlet weak var DOBTextField: UITextField!
    @IBOutlet weak var EmailTextField: UITextField!
    @IBOutlet weak var addStudentButton: UIButton!
    
    var titleName = ""
    let datePicker : UIDatePicker = UIDatePicker()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        addStudentButton.setTitle(titleName, for: .normal)
        print(titleName)
        DOBTextField.tag = 0
        if titleName == "Add Faculty"{
            facultyIdLabel.text = "Faculty ID :"
        }
        titleLabel.text = titleName
        
    }
    @IBAction func dateTextFieldBeginEditing(_ sender: UITextField) {
        showDatePicker(tag: sender.tag)
    }
    func showDatePicker(tag: Int){
        datePicker.datePickerMode = .date
        if #available(iOS 13.4, *) { datePicker.preferredDatePickerStyle = .inline }
        else { datePicker.preferredDatePickerStyle = .wheels }
        datePicker.maximumDate = Calendar.current.date(byAdding: .year, value: 0, to: Date())
        let toolbar = UIToolbar()
        toolbar.sizeToFit()
        let doneButton = UIBarButtonItem(title: "Done", style: UIBarButtonItem.Style.done, target: self, action: #selector(self.donedatePicker(_ :)))
        doneButton.tag = tag
        let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.flexibleSpace, target: nil, action: nil)
        let cancelButton = UIBarButtonItem(title: "Cancel", style: UIBarButtonItem.Style.plain, target: self, action: #selector(self.cancelDatePicker(_ :)))
        cancelButton.tag = tag
        toolbar.setItems([cancelButton ,spaceButton,doneButton], animated: false)
        self.DOBTextField.inputAccessoryView = toolbar
        self.DOBTextField.inputView = datePicker
    }
    @objc func cancelDatePicker(_ sender: UIButton){
        self.DOBTextField.text? = ""
        self.view.endEditing(true)
    }
    @objc func donedatePicker(_ sender: UIButton){
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        datePicker.maximumDate = Calendar.current.date(byAdding: .year, value: 0, to: Date())
        self.DOBTextField.text = formatter.string(from: datePicker.date)
        self.view.endEditing(true)
    }
    
    @IBAction func addStudentButtonAction(_ sender: UIButton) {
        
        if NameTextField.text?.isEmpty == true{
            showToast("Enter the Name")
        }else if StudentidTextField.text?.isEmpty == true{
            if titleName == "Add Faculty"{
                showToast("Enter the Faculty ID")
            }else{
            showToast("Enter the Student ID")
            }
        }else if ContactTextField.text?.isEmpty == true{
            showToast("Enter the Contact NO.")
        }else if AddressTextField.text?.isEmpty == true{
            showToast("Enter the Address")
        }else if DOBTextField.text?.isEmpty == true{
            showToast("Enter the DOB")
        }else if EmailTextField.text?.isEmpty == true{
            showToast("Enter the Email ID")
        }else{
            if !isValidPhone(testStr: ContactTextField.text ?? ""){
                showToast("Enter the Valid Contact Number")
            }else if !isValidEmail(emailStr: EmailTextField.text ?? ""){
                showToast("Enter the Valid Email Format")
            }else {
                validateDate(dateString: DOBTextField.text ?? "")
            }
        }
    }
    
    @IBAction func backButton(_ sender: UIButton) {
        
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func menuButton(_ sender: UIButton) {
        
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "MenuViewController") as! MenuViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }

}
extension AddStudentViewController{
    
    func addStudentAPI(){
        self.startIndicator()
        let apiURL = APIList().urlString(url:.AddStudent)
        let formData = ["name":"\(NameTextField.text ?? "Error")",
                   "studentid":"\(StudentidTextField.text ?? "Error")",
                   "contact":"\(ContactTextField.text ?? "Error")",
                   "address":"\(AddressTextField.text ?? "Error")",
                   "dob":"\(DOBTextField.text ?? "Error")",
                   "email":"\(EmailTextField.text ?? "Error")"]
    
        APIHandler().postAPIValues(type: AddStudentModel.self, apiUrl: apiURL, method: "POST", formData: formData) {  result in
               switch result {
               case .success(let data):
                   self.addStudents = data
                 print(data)
                   if self.addStudents.status == true{
                       DispatchQueue.main.async { [self] in
                           self.stopIndicator()
                           showToast(self.addStudents.message)
                           self.navigationController?.popViewController(animated: true)
                           if let lastViewController = self.navigationController?.viewControllers.last as? ManageStudentsViewController {
                               lastViewController.manageStudentsTableView.reloadData()
                           }
                      }
                   }
                   else if self.addStudents.status == false{
                   }
                   case .failure(let error):
                   print(error)
                   DispatchQueue.main.async {

                   let alert = UIAlertController(title: "Warning", message: "Something Went Error", preferredStyle: .alert)
                   alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { ok in
                       print("JSON Error")
                   })
                   self.present(alert, animated: true, completion: nil)
                   }
               }
           }
    }
    
    func validateDate(dateString: String){
        let dateFormat = "yyyy-MM-dd"
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = dateFormat
        if let date = dateFormatter.date(from: dateString), dateString == dateFormatter.string(from: date) {
            if self.titleLabel.text == "Add Student"{
                self.addStudentAPI()
            }else if self.titleLabel.text == "Add Faculty" {
                self.addFacultyAPI()
            }
            
        }else{
           showToast("Enter Valid Format DOB(yyyy-MM-dd)")
        }
    }
}

extension AddStudentViewController{
    
    func addFacultyAPI(){

   
    self.startIndicator()
    let apiURL = APIList().urlString(url:.AddFaculty)
    let formData = ["name":"\(NameTextField.text ?? "Error")",
               "facultyid":"\(StudentidTextField.text ?? "Error")",
               "contact":"\(ContactTextField.text ?? "Error")",
               "address":"\(AddressTextField.text ?? "Error")",
               "dob":"\(DOBTextField.text ?? "Error")",
               "email":"\(EmailTextField.text ?? "Error")"]

    APIHandler().postAPIValues(type: AddFacultyModel.self, apiUrl: apiURL, method: "POST", formData: formData) {  result in
           switch result {
           case .success(let data):
               self.addFaculty = data
             print(data)
               if self.addFaculty.status == true{
                   DispatchQueue.main.async { [self] in
                       self.stopIndicator()
                       showToast(self.addFaculty.message)
                       self.navigationController?.popViewController(animated: true)
                       if let lastViewController = self.navigationController?.viewControllers.last as? ManageStudentsViewController {
                           lastViewController.manageStudentsTableView.reloadData()
                       }
                  }
               }
               else if self.addFaculty.status == false{
               }
               case .failure(let error):
               print(error)
               DispatchQueue.main.async {

               let alert = UIAlertController(title: "Warning", message: "Something Went Error", preferredStyle: .alert)
               alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { ok in
                   print("JSON Error")
               })
               self.present(alert, animated: true, completion: nil)
               }
           }
       }
}
    
}

