//
//  ChangePasswordViewController.swift
//  clubactivity
//
//  Created by SAIL on 11/10/23.
//

import UIKit

class ChangePasswordViewController: BasicViewController {
    
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var confirmPasswordTextField: UITextField!
    var updateStudents : UpdateStudentModel!
    var changeFacultyPassword : ChangeFacultyPasswordModel!

    var studentName: String?
    var studentID: String?
    var titleName : String?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        print(studentName ?? "",studentID ?? "")
    }
    @IBAction func backButton(_ sender: UIButton) {
        
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func menuButton(_ sender: UIButton) {
        
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "MenuViewController") as! MenuViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    @IBAction func changeStudentPasswordButtonAction(_ sender: UIButton) {
        
        if passwordTextField.text?.isEmpty == true{
            showToast("Enter the Password")
        }else if confirmPasswordTextField.text?.isEmpty == true{
            showToast("Enter the Confirm Password")
        }else if (passwordTextField.text != confirmPasswordTextField.text ) {
            showToast("Password Mismatch")
        }else{
            self.getAPI()
        }
    }
}
extension ChangePasswordViewController{

    func getAPI(){
    if titleName == "Manage Students"{
        self.startIndicator()
        let apiURL = APIList().urlString(url:.changePasswordStudent)
        let formData = ["password":"\(passwordTextField.text ?? "Error")",
                        "studentid":"\(studentID ?? "Error")",
                   "confirmpassword":"\(confirmPasswordTextField.text ?? "Error")"]

        APIHandler().postAPIValues(type: UpdateStudentModel.self, apiUrl: apiURL, method: "POST", formData: formData) {  result in
               switch result {
               case .success(let data):
                   self.updateStudents = data
                 print(data)
                   if self.updateStudents.status == true{
                       DispatchQueue.main.async { [self] in
                           self.stopIndicator()
                           showToast(self.updateStudents.message)
                           self.navigationController?.popViewController(animated: true)
                      }
                   }
                   else if self.updateStudents.status == false{
                       self.showToast(self.updateStudents.message)
                       self.stopIndicator()
                   }
                   case .failure(let error):
                   print(error)
                   DispatchQueue.main.async {
                       self.stopIndicator()
                   let alert = UIAlertController(title: "Warning", message: "Something Went Error", preferredStyle: .alert)
                   alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { ok in
                       print("JSON Error")
                   })
                   self.present(alert, animated: true, completion: nil)
                   }
               }
           }
           
        }else if titleName == "Manage Faculties"{
            
            self.startIndicator()
            let apiURL = APIList().urlString(url:.changePasswordFaculty)
            let formData = ["password":"\(passwordTextField.text ?? "Error")",
                            "facultyid":"\(studentID ?? "Error")",
                       "confirmpassword":"\(confirmPasswordTextField.text ?? "Error")"]

            APIHandler().postAPIValues(type: ChangeFacultyPasswordModel.self, apiUrl: apiURL, method: "POST", formData: formData) {  result in
                   switch result {
                   case .success(let data):
                       self.changeFacultyPassword = data
                     print(data)
                       if self.changeFacultyPassword.status == true{
                           DispatchQueue.main.async { [self] in
                               self.stopIndicator()
                               showToast(self.changeFacultyPassword.message)
                               self.navigationController?.popViewController(animated: true)
                          }
                       }
                       else if self.changeFacultyPassword.status == false{
                           self.showToast(self.changeFacultyPassword.message)
                           self.stopIndicator()
                       }
                       case .failure(let error):
                       print(error)
                       DispatchQueue.main.async {
                           self.stopIndicator()
                       let alert = UIAlertController(title: "Warning", message: "Something Went Error", preferredStyle: .alert)
                       alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { ok in
                           print("JSON Error")
                       })
                       self.present(alert, animated: true, completion: nil)
                       }
                   }
            }
        }
    }
}
