//
//  FacultyLaunchCourseViewController.swift
//  clubactivity
//
//  Created by SAIL on 14/10/23.
//

import UIKit

class FacultyLaunchCourseViewController: BasicViewController {
    @IBOutlet weak var LaunchCourseTableView: UITableView!
    @IBOutlet weak var courseDetailLabel: UILabel!
    @IBOutlet weak var courseMessageLabel: UILabel!
    @IBOutlet weak var courseView: UIView!
    

    var facultyattendenceselect: FacultyattendenceselectModel!
    var facultylaunchcourse: FacultyLaunchCourseModel!
    var courseId = ""
    var selectedTitlesArray: [String] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        initalAPI()
        courseView.isHidden = false
    }
    
    @IBAction func backButton(_ sender: UIButton) {
        navigationController?.popViewController(animated: true)
    }

    @IBAction func menuButton(_ sender: UIButton) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "MenuViewController") as! MenuViewController
        navigationController?.pushViewController(vc, animated: true)
    }

    @IBAction func submitButton(_ sender: UIButton) {
        if selectedTitlesArray.contains("") {
                showAlert(title: "Warning", message: "Please select grades for all students")
            } else {
                // Proceed with your API call or any other logic
                postAPI()
            }
    }

    @IBAction func courseSelectButton(_ sender: UIButton) {
        showCourseDetailsActionSheet()
    }

    func showCourseDetailsActionSheet() {
        let actionSheet = UIAlertController(title: "Course Details", message: "Select a course", preferredStyle: .actionSheet)

        for course in facultyattendenceselect.courses {
            let action = UIAlertAction(title: course.courseName, style: .default) { [weak self] _ in
                self?.courseDetailLabel.text = course.courseName
                self?.GetAPI(courseID: course.courseID)
                self?.courseId = course.courseID
            }
            actionSheet.addAction(action)
        }

        actionSheet.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        present(actionSheet, animated: true, completion: nil)
    }
}

extension FacultyLaunchCourseViewController {
    func initalAPI() {
        startIndicator()
        let apiURL = APIList().urlString(url: .FacultyAttendenceSelect) + "facultyId=\(UserDefaultsManager.shared.getUserID() ?? "")"
        print(apiURL)
        APIHandler().getAPIValues(type: FacultyattendenceselectModel.self, apiUrl: apiURL, method: "GET") { [weak self] result in
            switch result {
            case .success(let data):
                DispatchQueue.main.async {
                self?.facultyattendenceselect = data
                print(data)
                self?.stopIndicator()
                }
            case .failure(let error):
                DispatchQueue.main.async {
                print(error)
                self?.stopIndicator()
                self?.showAlert(title: "Warning", message: "Something Went Error", okActionHandler: nil)
            }
            }
        }
    }

    func GetAPI(courseID: String) {
        let apiURL = APIList().urlString(url: .FacultyLaunchTwoCourse) + "courseId=\(courseID)"
        startIndicator()
        print(apiURL)
        APIHandler().getAPIValues(type: FacultyLaunchCourseModel.self, apiUrl: apiURL, method: "GET") { [weak self] result in
            switch result {
            case .success(let data):
                print(data)
                DispatchQueue.main.async {
                if data.status == true {
                    self?.courseView.isHidden = true
                    self?.facultylaunchcourse = data
                    self?.stopIndicator()
                    self?.showToast(data.message)
                    self?.LaunchCourseTableView.reloadData()
                } else if data.status == false {
                    self?.courseMessageLabel.text = data.message
                    self?.stopIndicator()
                    self?.showToast(data.message)
                    self?.LaunchCourseTableView.reloadData()
                }
                }
            case .failure(let error):
                DispatchQueue.main.async {
                print(error)
                self?.stopIndicator()
                self?.showAlert(title: "Warning", message: "Something Went Error", okActionHandler: nil)
            }
            }
        }
    }

    func postAPI() {
        startIndicator()

        let grades = selectedTitlesArray.joined(separator: ",")
        let studentIDs = facultylaunchcourse.data.map { $0.studentID }.joined(separator: ",")
        print(grades)
        print(studentIDs)
        let apiURL = APIList().urlString(url: .FacultyLaunchCoursePost)
        let formData = [
            "courseid": courseId,
            "grades": grades,
            "studentids": studentIDs
        ]
        print(apiURL)
        print(formData)

        APIHandler().postAPIValues(type: FacultyLaunchCoursePostModel.self, apiUrl: apiURL, method: "POST", formData: formData) { [weak self] result in
            switch result {
            case .success(let data):
                print(data)
            DispatchQueue.main.async {
                if data.status == true {
                    self?.stopIndicator()
                    self?.showToast(data.message)
                    self?.showAlert(title: "Success", message: data.message) {
                        let vc = self?.storyboard?.instantiateViewController(withIdentifier: "CalenderViewController") as! CalenderViewController
                        self?.navigationController?.pushViewController(vc, animated: true)
                    }
                } else if data.status == false {
                    self?.stopIndicator()
                    self?.showToast(data.message)
                }
            }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                self?.stopIndicator()
                self?.showAlert(title: "Warning", message: "Something Went Error", okActionHandler: nil)
            }
            }
        }
    }
}

extension FacultyLaunchCourseViewController: LaunchCourseCellDelegate {
    func didTapButton(in cell: launchCourseCell) {
        if let indexPath = LaunchCourseTableView.indexPath(for: cell) {
            let selectedTitle: String?

            if cell.exeButton.isHighlighted {
                selectedTitle = "Excellent"
            } else if cell.goodButton.isHighlighted {
                selectedTitle = "Good"
            } else if cell.avgButton.isHighlighted {
                selectedTitle = "Average"
            } else {
                selectedTitle = nil
            }

            if let selectedTitle = selectedTitle {
                // Ensure that selectedTitlesArray has enough capacity
                while selectedTitlesArray.count <= indexPath.row {
                    selectedTitlesArray.append("")
                }

                selectedTitlesArray[indexPath.row] = selectedTitle
                print(selectedTitlesArray)
            }
        }
    }
}

extension FacultyLaunchCourseViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return facultylaunchcourse?.data.count ?? 0
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "launchCourseCell") as! launchCourseCell
        cell.backgroundColor = .white
        cell.View.layer.borderColor = UIColor.black.cgColor
        cell.View.layer.borderWidth = 1
        cell.View.layer.cornerRadius = 8
        cell.View.clipsToBounds = true
        cell.nameLabel.text = facultylaunchcourse.data[indexPath.row].name
        cell.studentIdLabel.text = facultylaunchcourse.data[indexPath.row].studentID
        cell.exeButton.addTarget(cell, action: #selector(cell.exeButtonTapped(_:)), for: .touchUpInside)
        cell.goodButton.addTarget(cell, action: #selector(cell.goodButtonTapped(_:)), for: .touchUpInside)
        cell.avgButton.addTarget(cell, action: #selector(cell.avgButtonTapped(_:)), for: .touchUpInside)
        cell.delegate = self

        // Ensure that selectedTitlesArray has enough capacity
        while selectedTitlesArray.count <= indexPath.row {
            selectedTitlesArray.append("")
        }

        return cell
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 150
    }
}


protocol LaunchCourseCellDelegate: AnyObject {
    func didTapButton(in cell: launchCourseCell)
}
class launchCourseCell: UITableViewCell {
    
    @IBOutlet weak var View: UIView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var studentIdLabel: UILabel!
    @IBOutlet weak var exeButton: UIButton!
    @IBOutlet weak var goodButton: UIButton!
    @IBOutlet weak var avgButton: UIButton!
    @IBOutlet weak var exeImageButton: UIButton!
    @IBOutlet weak var goodImageButton: UIButton!
    @IBOutlet weak var avgImageButton: UIButton!
   
    
    weak var delegate: LaunchCourseCellDelegate?

       @IBAction func exeButtonTapped(_ sender: UIButton) {
           delegate?.didTapButton(in: self)
           clearAllImages()
           setButtonImage(exeImageButton, imageName: "PresentMark")
       }

       @IBAction func goodButtonTapped(_ sender: UIButton) {
           delegate?.didTapButton(in: self)
           clearAllImages()
           setButtonImage(goodImageButton, imageName: "PresentMark")
       }

       @IBAction func avgButtonTapped(_ sender: UIButton) {
           delegate?.didTapButton(in: self)
           clearAllImages()
           setButtonImage(avgImageButton, imageName: "PresentMark")
       }

       private func setButtonImage(_ button: UIButton, imageName: String) {
           button.setImage(UIImage(named: imageName), for: .normal)
       }

       private func clearAllImages() {
           exeImageButton.setImage(nil, for: .normal)
           goodImageButton.setImage(nil, for: .normal)
           avgImageButton.setImage(nil, for: .normal)
       }
   }
