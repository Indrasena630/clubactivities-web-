//
//  FacultyRegistrationViewController.swift
//  clubactivity
//
//  Created by SAIL on 14/10/23.
//

import UIKit


class FacultyRegistrationViewController: BasicViewController {
    
    @IBOutlet weak var registrationTableView: UITableView!
    @IBOutlet weak var courseDetailLabel: UILabel!
    @IBOutlet weak var courseMessageLabel: UILabel!
    @IBOutlet weak var courseView: UIView!
    var facultyattendenceselect : FacultyattendenceselectModel!
    var facultyregistration: FacultyRegistrationModel!
    var studentpostregistration: FacultyRegistrationPostModel!
    var rejectPostregistration: FacultyRejectPostModel!
    var courseapproval: FacultyRegistration?
    var courseIdPost = ""
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initalAPI()
    }
    
   
    
    @objc func acceptButton(sender: UIButton) {
        let studentID = facultyregistration?.data?[sender.tag].studentId ?? ""
        self.postPresentAPI(studentID: studentID)
       
    }
    @objc func rejectButton(sender: UIButton) {
        let studentID = facultyregistration?.data?[sender.tag].studentId ?? ""
        self.postRejectAPI(studentID: studentID)
       
    }
    
    @IBAction func backButton(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func menuButton(_ sender: UIButton) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "MenuViewController") as! MenuViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    @IBAction func courseSelectButton(_ sender: UIButton) {
            showCourseDetailsActionSheet()
    }
}


extension FacultyRegistrationViewController
{
    func showCourseDetailsActionSheet() {
        let actionSheet = UIAlertController(title: "Course Details", message: "Select a course", preferredStyle: .actionSheet)
        for course in facultyattendenceselect.courses {
            let action = UIAlertAction(title: course.courseName, style: .default) { [weak self] _ in
                DispatchQueue.main.async {
                    self?.courseDetailLabel.text = course.courseName
                    self?.GetAPI(courseID: course.courseID)
                    self?.courseIdPost = course.courseID
                }
            }
            actionSheet.addAction(action)
        }
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        actionSheet.addAction(cancelAction)
        present(actionSheet, animated: true, completion: nil)
    }
    
 func initalAPI() {
       startIndicator()
       let apiURL = APIList().urlString(url: .FacultyAttendenceSelect) + "facultyId=\(UserDefaultsManager.shared.getUserID() ?? "")"
       print(apiURL)
       APIHandler().getAPIValues(type:FacultyattendenceselectModel.self, apiUrl: apiURL, method: "GET") { result in
           switch result {
           case .success(let data):
               DispatchQueue.main.async {
               self.facultyattendenceselect = data
               print(data)
                   self.stopIndicator()
               }
           case .failure(let error):
               print(error)
               DispatchQueue.main.async { [self] in
                   stopIndicator()
                   showAlert(title: "Warning", message: "Something Went Error", okActionHandler: nil)
               }
           }
       }
   }
func GetAPI(courseID : String){
    self.courseView.isHidden = false
    let apiURL = APIList().urlString(url:.FacultyRegistration)+"courseId=\(courseID)"
    self.startIndicator()
    print(apiURL)
    APIHandler().getAPIValues(type: FacultyRegistrationModel.self, apiUrl: apiURL,method:"GET"){
        result in
        switch result {
        case .success(let data):
            self.facultyregistration = data
            print(data)
            DispatchQueue.main.async { [self] in
                if facultyregistration.status == true{
                    self.courseView.isHidden = true
                    if facultyregistration.data?.count == 0 {
                        self.showToast("No Students data found")
                    }else{
                        self.showToast(facultyregistration.message ?? "")
                    }
                }
                else if facultyregistration.status == false{
                    courseMessageLabel.text = data.message
                    self.showToast(facultyregistration.message ?? "")
                }
                self.stopIndicator()
                self.registrationTableView.reloadData()
            }
        case .failure(let error):
            print(error)
            DispatchQueue.main.async {
                self.stopIndicator()
                self.showAlert(title: "Warning", message: "Something Went Error",okActionHandler: nil)
            }
        }
    }
}
    
func postPresentAPI(studentID: String) {
        self.startIndicator()
        let apiURL = APIList().urlString(url: .FacultyRegistrationPost)
        
        let formData = ["courseid": courseIdPost,
                        "studentstatus": "Approved",
                        "studentid": studentID]
        print(apiURL)
        print(formData)
        APIHandler().postAPIValues(type: FacultyRegistrationPostModel.self, apiUrl: apiURL, method: "POST", formData: formData) { result in
            switch result {
            case .success(let data):
                self.studentpostregistration = data
                print(data)
                if self.studentpostregistration.success == true {
                    DispatchQueue.main.async { [self] in
                        self.stopIndicator()
                        showToast(self.studentpostregistration.message)
                        
                    }
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                    self.showAlert(title: "Warning", message: "Something Went Error",okActionHandler: nil)
                }
            }
        }
    }
func postRejectAPI(studentID: String) {
            self.startIndicator()
            let apiURL = APIList().urlString(url: .RegistrationReject)
            
            let formData = ["courseid": courseIdPost,
                            "studentstatus": "Rejected",
                            "studentid": studentID]
            print(apiURL)
            print(formData)
            APIHandler().postAPIValues(type: FacultyRejectPostModel.self, apiUrl: apiURL, method: "POST", formData: formData) { result in
                switch result {
                case .success(let data):
                    DispatchQueue.main.async { [self] in
                    self.rejectPostregistration = data
                    print(data)
                    if data.status == true {
                        stopIndicator()
                        showToast(data.message)
                        GetAPI(courseID: courseIdPost)
                        registrationTableView.reloadData()
                        }
                    }
                case .failure(let error):
                    print(error)
                    DispatchQueue.main.async {
                        self.stopIndicator()
                        self.showAlert(title: "Warning", message: "Something Went Error",okActionHandler: nil)
                    }
                }
            }
        }
}
extension FacultyRegistrationViewController : UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return facultyregistration?.data?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "registrationCell") as! registrationCell
        cell.backgroundColor = UIColor.white
        cell.View.layer.borderColor = UIColor.black.cgColor
        cell.View.layer.borderWidth = 1
        cell.View.layer.cornerRadius = 8
        cell.View.clipsToBounds = true
        cell.updateButton.tag = indexPath.row
        cell.rejectButton.tag = indexPath.row
        cell.updateButton.addTarget(self, action: #selector(acceptButton(sender:)), for: .touchUpInside)
        cell.rejectButton.addTarget(self, action: #selector(rejectButton(sender:)), for: .touchUpInside)
        cell.nameLabel.text = facultyregistration?.data?[indexPath.row].name
        cell.studentIdLabel.text = facultyregistration?.data?[indexPath.row].studentId
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
}
class registrationCell: UITableViewCell {
    @IBOutlet weak var View: UIView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var studentIdLabel: UILabel!
    @IBOutlet weak var updateButton: UIButton!
    @IBOutlet weak var rejectButton: UIButton!
}
extension UIAlertController {
    func setBoldTitle(_ title: String) {
        let titleAttribute = [NSAttributedString.Key.font: UIFont.boldSystemFont(ofSize: 25)]
        let titleString = NSAttributedString(string: title, attributes: titleAttribute)
        self.setValue(titleString, forKey: "attributedTitle")
    }
}
