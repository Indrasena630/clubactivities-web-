//
//  FacultyAttendenceViewController.swift
//  clubactivity
//
//  Created by SAIL on 17/10/23.
//


import UIKit

struct StudentAttendance {
    var studentId: String
    var studentName: String
    var attendanceStatus: AttendanceStatus
}

enum AttendanceStatus {
    case present
    case absent
}
protocol AttendenceCellDelegate: AnyObject {
    func didChangeAttendanceStatus(for cell: AttendenceCell, status: AttendanceStatus)
}

class FacultyAttendenceViewController: BasicViewController {

    @IBOutlet weak var AttendenceTableView: UITableView!
    @IBOutlet weak var submitButtonOutlet: UIButton!
    @IBOutlet weak var courseDetailLabel: UILabel!
    @IBOutlet weak var courseMessageLabel: UILabel!
    @IBOutlet weak var courseView: UIView!
    var studentAttendances: [StudentAttendance] = []
    var facultyattendence : FacultyAttendenceModel!
    var courseAttendenceId = ""
    var facultyattendenceselect : FacultyattendenceselectModel!
  
   override func viewDidLoad() {
       super.viewDidLoad()
       initalAPI()
       courseView.isHidden = false
   }
 
   @IBAction func backButton(_ sender: UIButton) {
       self.navigationController?.popViewController(animated: true)
   }
   @IBAction func menuButton(_ sender: UIButton) {
       let vc = self.storyboard?.instantiateViewController(withIdentifier: "MenuViewController") as! MenuViewController
       self.navigationController?.pushViewController(vc, animated: true)
   }
    @IBAction func courseSelectButton(_ sender: UIButton) {
        
            showCourseDetailsActionSheet()

    }
   @IBAction func submitButton(_ sender: UIButton) {

      let vc = self.storyboard?.instantiateViewController(withIdentifier: "AbsentListViewController") as! AbsentListViewController
       vc.courseId = courseAttendenceId
       vc.allAttendances = studentAttendances
      self.navigationController?.present(vc, animated: true, completion: nil)

  }
    func showCourseDetailsActionSheet() {
        let actionSheet = UIAlertController(title: "Course Details", message: "Select a course", preferredStyle: .actionSheet)

        for course in facultyattendenceselect.courses {
            let action = UIAlertAction(title: course.courseName, style: .default) { [weak self] _ in
                DispatchQueue.main.async {
                    self?.courseDetailLabel.text = course.courseName
                    self?.GetAPI(courseID: course.courseID)
                    self?.courseAttendenceId = course.courseID
                }
            }
            actionSheet.addAction(action)
        }

        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        actionSheet.addAction(cancelAction)
        present(actionSheet, animated: true, completion: nil)
    }
}

//MARK: Api Integration
extension FacultyAttendenceViewController{
 func initalAPI() {
    startIndicator()
    let apiURL = APIList().urlString(url: .FacultyAttendenceSelect) + "facultyId=\(UserDefaultsManager.shared.getUserID() ?? "")"
    print(apiURL)
    APIHandler().getAPIValues(type:FacultyattendenceselectModel.self, apiUrl: apiURL, method: "GET") { result in
        switch result {
        case .success(let data):
            DispatchQueue.main.async {
            self.facultyattendenceselect = data
            print(data)
                self.stopIndicator()
            }
        case .failure(let error):
            print(error)
            DispatchQueue.main.async { [self] in
                stopIndicator()
                showAlert(title:  "Warning", message: "Something Went Error", okActionHandler: nil)
            }
        }
    }
}
func GetAPI(courseID : String){
        self.courseView.isHidden = false
    let apiURL = APIList().urlString(url:.FacultyAttendence)+"courseId=\(                                                                 courseID)"
    self.startIndicator()
    print(apiURL)
    APIHandler().getAPIValues(type: FacultyAttendenceModel.self, apiUrl: apiURL,method:"GET"){  result in
    switch result {
    case .success(let data):
        self.facultyattendence = data
    print(data)
        DispatchQueue.main.async { [self] in
        if self.facultyattendence.status == true{
            self.courseView.isHidden = true
        if facultyattendence.data.count == 0 {
            self.showToast("No Students data found")
            self.submitButtonOutlet.isHidden = true
        }else{
            self.submitButtonOutlet.isHidden = false
            self.showToast(self.facultyattendence.message)
            self.studentAttendances = facultyattendence.data.map { studentData in
                return StudentAttendance(
                    studentId: studentData.studentID,studentName: studentData.name, attendanceStatus: .present)
                }
            }
        }
        else if self.facultyattendence.status == false{
            courseMessageLabel.text = facultyattendence.message
            self.showToast(self.facultyattendence.message)
        }
            self.stopIndicator()
            self.AttendenceTableView.reloadData()
    }
        case .failure(let error):
        print(error)
        DispatchQueue.main.async {
            self.stopIndicator()
            self.showAlert(title:  "Warning", message: "Something Went Error",okActionHandler: nil)
        }
    }
    }
 }
}
extension FacultyAttendenceViewController: AttendenceCellDelegate {
    func didChangeAttendanceStatus(for cell: AttendenceCell, status: AttendanceStatus) {
        if let indexPath = AttendenceTableView.indexPath(for: cell) {
            studentAttendances[indexPath.row].attendanceStatus = status
        }
    }
}
extension FacultyAttendenceViewController : UITableViewDelegate, UITableViewDataSource{
func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
         return studentAttendances.count
     }
    
func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "AttendenceCell") as! AttendenceCell
        let studentAttendance = studentAttendances[indexPath.row]
        cell.nameLabel.text = studentAttendance.studentName
        cell.studentIdLabel.text = studentAttendance.studentId
        if studentAttendance.attendanceStatus == .present {
            cell.presentButton.setImage(UIImage(named: "PresentMark"), for: .normal)
            cell.absentButton.setImage(nil, for: .normal)
        } else {
            cell.absentButton.setImage(UIImage(named: "AbsentMark"), for: .normal)
            cell.presentButton.setImage(nil, for: .normal)
        }
         cell.absentButton.addTarget(cell, action: #selector(cell.absentButtonTapped(_:)), for: .touchUpInside)
         cell.presentButton.addTarget(cell, action: #selector(cell.presentButtonTapped(_:)), for: .touchUpInside)
    cell.delegate = self
                 return cell
             }
func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
         return 80
     }
     
 }
class AttendenceCell: UITableViewCell {

    @IBOutlet weak var View: UIView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var studentIdLabel: UILabel!
    @IBOutlet weak var presentButton: UIButton!
    @IBOutlet weak var absentButton: UIButton!
    
    var attendanceStatus: AttendanceStatus = .present
    weak var delegate: AttendenceCellDelegate?
    
    @IBAction func presentButtonTapped(_ sender: UIButton) {
        attendanceStatus = .present
        presentButton.setImage(UIImage(named: "PresentMark"), for: .normal)
        absentButton.setImage(nil, for: .normal)
        delegate?.didChangeAttendanceStatus(for: self, status: attendanceStatus)
    }

    @IBAction func absentButtonTapped(_ sender: UIButton) {
        attendanceStatus = .absent
        absentButton.setImage(UIImage(named: "AbsentMark"), for: .normal)
        presentButton.setImage(nil, for: .normal)
        delegate?.didChangeAttendanceStatus(for: self, status: attendanceStatus)
    }

}
