//
//  AbsentListViewController.swift
//  clubactivity
//
//  Created by SAIL on 30/11/23.
//

import UIKit

class AbsentListViewController: BasicViewController {
    
    @IBOutlet weak var absentView: UIView!
    @IBOutlet weak var noDataView: UIView!
    @IBOutlet weak var absentTableView: UITableView!{
        didSet{
            absentTableView.dataSource = self
            absentTableView.delegate = self
        }
    }
    var facultypostattendence : FacultyAttendencePostModel!
    var allAttendances: [StudentAttendance] = []
    var absentAttendances: [StudentAttendance] {
            return allAttendances.filter { $0.attendanceStatus == .absent }
        }
    var courseId = ""
    override func viewDidLoad() {
        super.viewDidLoad()

        print(allAttendances.count,"..........>",absentAttendances.count)
       
    }
    @IBAction func yesButton(_ sender: UIButton) {
        
        postAPI()

    }
    @IBAction func noButton(_ sender: UIButton) {
        
        self.dismiss(animated: true, completion: nil)

    }
    @IBAction func absentBackButton(_ sender: UIButton) {
        
        self.dismiss(animated: true, completion: nil)

    }
    func postAPI() {
            self.startIndicator()
        let studentIDs = allAttendances.map { $0.studentId }.joined(separator: ",")
        let studentStatuses = allAttendances.map { $0.attendanceStatus }.map { "\($0)" }.joined(separator: ",")

        print("studentIDs:\(studentIDs)",
              "studentStatuses:\(studentStatuses)"
        )

            let apiURL = APIList().urlString(url: .FacultyAttendencePost)
            let formData: [String: Any] = ["courseid": courseId, "studentstatuses": studentStatuses, "studentids": studentIDs]
            print(apiURL,formData)
            APIHandler().postAPIValues(type: FacultyAttendencePostModel.self, apiUrl: apiURL, method: "POST", formData: formData) { result in
                switch result {
                case .success(let data):
                    self.facultypostattendence = data
                    print(data)
                    if self.facultypostattendence.status == true {
                        DispatchQueue.main.async {
                            self.stopIndicator()
                            self.showToast(self.facultypostattendence.message)
                            self.showAlert(title: "Success", message: data.message, okActionHandler: {
                                self.dismiss(animated: true, completion: nil)
                            })
                        }
                           
                    } else if self.facultypostattendence.status == false {
                        DispatchQueue.main.async {
                            self.stopIndicator()
                            self.showToast(self.facultypostattendence.message)
                        }
                    }
                case .failure(let error):
                    print(error)
                    DispatchQueue.main.async {
                        self.stopIndicator()
                        self.showAlert(title: "Warning", message: "Something Went Error",okActionHandler: nil)
                    }
                }
            }
        }
   
}
extension AbsentListViewController : UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return absentAttendances.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell =  tableView.dequeueReusableCell(withIdentifier: "AbsentTableViewCell") as! AbsentTableViewCell
        if absentAttendances.count == 0 {
            noDataView.isHidden = false
            absentTableView.isHidden = true
        }else{
            noDataView.isHidden = true
            absentTableView.isHidden = false
        
        cell.backgroundColor = UIColor.white
        cell.View.layer.borderColor = UIColor.black.cgColor
        cell.View.layer.borderWidth = 1
        cell.View.layer.cornerRadius = 8
        cell.View.clipsToBounds = true
        let studentAttendance = absentAttendances[indexPath.row]
            cell.nameLabel.text = studentAttendance.studentName
            cell.studentIdLabel.text = studentAttendance.studentId
        cell.absentLabel.text = studentAttendance.attendanceStatus == .absent ? "absent" : ""


        }
            return cell
        
       
    }
       
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {

             return 50
    }
    
}

class AbsentTableViewCell : UITableViewCell {

    @IBOutlet weak var View: UIView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var studentIdLabel: UILabel!
    @IBOutlet weak var absentLabel: UILabel!
}
