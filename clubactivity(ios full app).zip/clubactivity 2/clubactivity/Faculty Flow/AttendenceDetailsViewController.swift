//
//  AttendenceDetailsViewController.swift
//  clubactivity
//
//  Created by SAIL on 30/11/23.
//

import UIKit

class AttendenceDetailsViewController: BasicViewController {
    
    @IBOutlet weak var AttendenceDetailsTableView: UITableView!{
        didSet{
            AttendenceDetailsTableView.dataSource = self
            AttendenceDetailsTableView.delegate = self
        }
    }
    @IBOutlet weak var courseDetailLabel: UILabel!
    @IBOutlet weak var courseMessageLabel: UILabel!
    @IBOutlet weak var courseView: UIView!
    var courseList: courseListModel!
    var courseAttendence: courseAttendenceModel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        courseAPI()
    }
   
    @IBAction func backButton(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func menuButton(_ sender: UIButton) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "MenuViewController") as! MenuViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    @IBAction func courseSelectButton(_ sender: UIButton) {
        
            showCourseDetailsActionSheet()

    }
    func showCourseDetailsActionSheet() {
        let actionSheet = UIAlertController(title: "Course Details", message: "Select a course", preferredStyle: .actionSheet)

        for course in courseList.courses {
            let action = UIAlertAction(title: course.courseName, style: .default) { [weak self] _ in
                DispatchQueue.main.async {
                    self?.courseDetailLabel.text = course.courseName
                    self?.GetAPI(courseID: course.courseID)
                    
                }
            }
            actionSheet.addAction(action)
        }

        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        actionSheet.addAction(cancelAction)
        present(actionSheet, animated: true, completion: nil)
    }
   
}
extension AttendenceDetailsViewController{
    func courseAPI() {
        startIndicator()
        let apiURL = APIList().urlString(url: .CourseList) + "facultyId=\(UserDefaultsManager.shared.getUserID() ?? "")"
        print(apiURL)
        APIHandler().getAPIValues(type:courseListModel.self, apiUrl:      apiURL, method: "GET") { result in
            switch result {
            case .success(let data):
                DispatchQueue.main.async {
                self.courseList = data
                print(data)
                    self.stopIndicator()
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async { [self] in
                    stopIndicator()
                    showAlert(title:  "Warning", message: "Something Went Error", okActionHandler: nil)
                }
            }
        }
    }
    
    func GetAPI(courseID : String){
     self.courseView.isHidden = false
        let apiURL =                        APIList().urlString(url:.CourseAttendence)+"courseId=\(courseID)"
        self.startIndicator()
        print(apiURL)
        APIHandler().getAPIValues(type: courseAttendenceModel.self, apiUrl: apiURL,method:"GET"){  result in
            switch result {
              case .success(let data):
              print(data)
                 DispatchQueue.main.async { [self] in
                    if data.status == true{
                    courseView.isHidden = true
                    courseAttendence = data
                     showToast(data.message)
                    }
                     else if data.status == false{
                         courseMessageLabel.text = data.message
                         self.showToast(data.message)
                     }
                    self.stopIndicator()
                    self.AttendenceDetailsTableView.reloadData()
                 }
                case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                    self.stopIndicator()
                    self.showAlert(title:"Warning", message: "Something Went Error",okActionHandler: nil)
                }
            }
        }
    }
}
extension AttendenceDetailsViewController : UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return courseAttendence?.data.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "AttendenceDetailsCell") as! AttendenceDetailsCell
        cell.backgroundColor = UIColor.white
        cell.View.layer.borderColor = UIColor.black.cgColor
        cell.View.layer.borderWidth = 1
        cell.View.layer.cornerRadius = 8
        cell.View.clipsToBounds = true
        let detailData = courseAttendence.data[indexPath.row]
        cell.nameLabel.text = detailData.name
        cell.StudentIDLabel.text = detailData.studentID
        cell.attendedClassesLabel.text = detailData.attendedClasses
        cell.totalClassesLabel.text = detailData.totalClasses
        cell.percentageLabel.text = "\(detailData.percentage) %"
        
      
       
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 150
    }
}

class AttendenceDetailsCell: UITableViewCell {

    @IBOutlet weak var View: UIView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var StudentIDLabel: UILabel!
    @IBOutlet weak var attendedClassesLabel: UILabel!
    @IBOutlet weak var totalClassesLabel: UILabel!
    @IBOutlet weak var percentageLabel: UILabel!
}
