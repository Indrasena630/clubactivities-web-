//
//  ApiList.swift
//  clubactivity
//
//  Created by SAIL on 18/10/23.
//

import Foundation
import CoreText

struct APIList
{

    let BASE_URL = "http://192.168.106.220//ios/"
  
    func urlString(url: urlString) -> String
    {
        return BASE_URL + url.rawValue
    }
}

enum urlString: String

{
    case AdminLogin = "adminlogin.php?"
    case StudentLogin = "login.php?"
    case FacultyLogin = "facultylogin.php?"
    case ManageStudent = "managestudent.php?"
    case AddStudent = "addstudent.php"
    case UpdateStudent = "updatestudent.php"
    case UpdateFaculty = "updatefaculty.php"
    case changePasswordStudent = "updatestudentpassword.php"
    case changePasswordFaculty = "updatefacultypassword.php"
    case DeleteStudent = "deletestudent.php"
    case DeleteFaculty = "deletefaculty.php"
    case ManageCourse  = "managecourse.php"
    case AddCourse = "addcourse.php"
    case ManageFaculty = "managefaculty.php"
    case AddFaculty = "addfaculty.php"
    case StudentAttendence = "studentattendence.php?"
    case StudentStatus = "studentstatus.php?"
    case GetEnrollment = "studentenrollmentget.php"
    case PostEnrollment = "studentenrollmentpost.php"
    case StudentProfile = "studentprofile.php?"
    case StudentEditProfile = "studenteditprofile.php"
    case FacultyProfile = "facultyprofile.php?"
    case FacultyEditProfile = "facultyeditprofile.php"
    case FacultyAttendence = "facattendancemarkingtwo.php?"
    case FacultyAttendenceSelect = "facattendancemarkingone.php?"
    case FacultyAttendencePost = "facultyattendencepost.php"
    case FacultyRegistration = "facultyregistration.php?"
    case FacultyRegistrationPost = "facultyregistrationpost.php"
    case FacultyLaunchCourse = "facultylaunchcourse.php?"
    case FacultyLaunchTwoCourse = "faclaunchcoursetwo.php?"
    case FacultyLaunchCoursePost = "facultylaunchcoursepost.php"
    case CourseList = "courseattendencefacone.php?"
    case CourseAttendence = "courseattendencefactwo.php?"
    case RegistrationReject = "facultyregistrationrejecttwopost.php"
    
    
    
}

