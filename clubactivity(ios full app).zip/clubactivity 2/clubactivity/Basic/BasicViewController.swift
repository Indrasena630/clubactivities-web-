//
//  BasicViewController.swift
//  clubactivity
//
//  Created by SAIL on 12/10/23.
//

import UIKit

class BasicViewController: UIViewController {

    var selectedValue: String?
    
    
    let overlayView = UIView(frame: UIScreen.main.bounds)
    let activityIndicator = UIActivityIndicatorView(style: .large)
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    
    //MARK: Validation function
    
    func isValidEmail(emailStr:String) -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailPred = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailPred.evaluate(with: emailStr)
    }
    
    func isValidPhone(testStr:String) -> Bool {
        let phoneRegEx = "^[6-9]\\d{9}$"
        let phoneNumber = NSPredicate(format:"SELF MATCHES %@", phoneRegEx)
        return phoneNumber.evaluate(with: testStr)
    }
    
    //MARK: Alert Message
    
//    func showAlert(title: String, message: String, preferredStyle: UIAlertController.Style = .alert, completion: (() -> Void)? = nil) {
//        let alertController = UIAlertController(title: title, message: message, preferredStyle: preferredStyle)
//        let okAction = UIAlertAction(title: "OK", style: .default) { (_) in completion?()}
//        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel) { (_) in}
//        alertController.addAction(okAction)
//        alertController.addAction(cancelAction)
//        if let viewController = UIApplication.shared.keyWindow?.rootViewController {
//            viewController.present(alertController, animated: true, completion: nil)
//        }
//    }

    func showActionSheet(sender: UIButton, contentString: [String]) {
        let actionSheetAlertController: UIAlertController = UIAlertController(title: nil, message: "Select", preferredStyle: .actionSheet)
        if contentString.count > 0 {
            for n in 0..<contentString.count {
                let action = UIAlertAction(title: contentString[n], style: .default) { (action) in
                    self.selectedValue = contentString[n]
                    self.updateButtonTitle(sender: sender)
                }
                action.setValue(CATextLayerAlignmentMode.left, forKey: "titleTextAlignment")
                action.setValue(UIColor.black, forKey: "titleTextColor")
                actionSheetAlertController.addAction(action)
            }
        } else {
            print("No data to display")
        }
        let cancelActionButton = UIAlertAction(title: "Cancel", style: .destructive, handler: nil)
        actionSheetAlertController.addAction(cancelActionButton)
        self.present(actionSheetAlertController, animated: true, completion: nil)
    }

    func updateButtonTitle(sender: UIButton) {
        if let selectedValue = self.selectedValue {
            print("selectedValue: \(selectedValue)")
            sender.setTitle(selectedValue, for: .normal)
            sender.setTitleColor(.black, for: .normal)
        }
    }
    //MARK: Active Indicator
    
    func startIndicator(){
        //MARK: UIView
        overlayView.backgroundColor = UIColor.black.withAlphaComponent(0.5)
        view.addSubview(overlayView)
        //MARK: Indicator
        activityIndicator.center = overlayView.center
        overlayView.addSubview(activityIndicator)
        activityIndicator.color = UIColor.red
        activityIndicator.hidesWhenStopped = true
        activityIndicator.startAnimating()
    }
    //MARK: removeIndicator
    func stopIndicator(){
        
        activityIndicator.stopAnimating()
        overlayView.removeFromSuperview()
    }
    
    //MARK: Toast Message Alert
    
    static let DELAY_SHORT = 1.5
    static let DELAY_LONG = 3.0
    
    func showToast(_ text: String, delay: TimeInterval = DELAY_LONG) {
        let label = ToastLabel()
        label.backgroundColor = UIColor(white: 0, alpha: 1)
        label.textColor = .white
        label.textAlignment = .center
        label.font = UIFont.systemFont(ofSize: 15)
        label.alpha = 0
        label.text = text
        label.clipsToBounds = true
        label.layer.cornerRadius = 10
        label.numberOfLines = 0
        label.textInsets = UIEdgeInsets(top: 10, left: 15, bottom: 10, right: 15)
        label.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(label)
        
        let saveArea = view.safeAreaLayoutGuide
        label.centerXAnchor.constraint(equalTo: saveArea.centerXAnchor, constant: 0).isActive = true
        label.leadingAnchor.constraint(greaterThanOrEqualTo: saveArea.leadingAnchor, constant: 15).isActive = true
        label.trailingAnchor.constraint(lessThanOrEqualTo: saveArea.trailingAnchor, constant: -15).isActive = true
        label.bottomAnchor.constraint(equalTo: saveArea.bottomAnchor, constant: -30).isActive = true
        UIView.animate(withDuration: 0.2, delay: 0, options: .curveEaseIn, animations: {
            label.alpha = 1
        }, completion: { _ in
            UIView.animate(withDuration: 0.2, delay: delay, options: .curveEaseOut, animations: {
                label.alpha = 0
            }, completion: {_ in
                label.removeFromSuperview()
            })
        })
    }
}
extension BasicViewController {
    func showAlert(title: String, message: String, okActionHandler: (() -> Void)? = nil) {
            let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
            
            let okAction = UIAlertAction(title: "OK", style: .default) { _ in
                okActionHandler?()
            }
            
            alertController.addAction(okAction)
            present(alertController, animated: true, completion: nil)
        }
}

class ToastLabel: UILabel {
    var textInsets = UIEdgeInsets.zero {
        didSet { invalidateIntrinsicContentSize() }
    }
    override func textRect(forBounds bounds: CGRect, limitedToNumberOfLines numberOfLines: Int) -> CGRect {
        let insetRect = bounds.inset(by: textInsets)
        let textRect = super.textRect(forBounds: insetRect, limitedToNumberOfLines: numberOfLines)
        let invertedInsets = UIEdgeInsets(top: -textInsets.top, left: -textInsets.left, bottom: -textInsets.bottom, right: -textInsets.right)
        return textRect.inset(by: invertedInsets)
    }
    override func drawText(in rect: CGRect) {
        super.drawText(in: rect.inset(by: textInsets))
    }
}


//MARK: cornerRadius

@IBDesignable extension UIButton {
        @IBInspectable var cornerRadius: CGFloat {
        set { layer.cornerRadius = newValue }
        get { return layer.cornerRadius }
    }
}
@IBDesignable extension UIView {
    @IBInspectable var cornerRadiusView: CGFloat {
        set { layer.cornerRadius = newValue }
        get { return layer.cornerRadius }
    }
}
@IBDesignable extension UILabel {
    @IBInspectable var cornerLabel: CGFloat {
        set { layer.cornerRadius = newValue }
        get { return layer.cornerRadius }
    }
}

class UserDefaultsManager {
    static let shared = UserDefaultsManager()

    private let userDefaults = UserDefaults.standard

    private init() {}
    // MARK: - Define Keys for Your Data
    private let userNameKey = "UserName"
    private let userIdKey = "UserID"
    // MARK: - Save Data
    func saveUserName(_ name: String) {
        userDefaults.set(name, forKey: userNameKey)
    }
    func saveUserID(_ age: String) {
        userDefaults.set(age, forKey: userIdKey)
    }
    // MARK: - Retrieve Data
    func getUserName() -> String? {
        return userDefaults.string(forKey: userNameKey)
    }
    func getUserID() -> String? {
        return userDefaults.string(forKey: userIdKey)
    }
    // MARK: - Remove Data (if needed)
    func removeUserData() {
        userDefaults.removeObject(forKey: userNameKey)
        userDefaults.removeObject(forKey: userIdKey)
    }
}



