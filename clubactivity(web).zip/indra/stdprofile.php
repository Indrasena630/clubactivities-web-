<?php
include("stdheader.php");
?>
<!DOCTYPE html>
<html>
<head>
    <!-- bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-aFq/bzH65dt+w6FI2ooMVUpc+21e0SRygnTpmBvdBgSdnuTN7QbdgL+OapgHtvPp" crossorigin="anonymous">
    <link rel="stylesheet" href="profile.css">
</head>
<body>
    <div class="container">
        <h1>Profile</h1>
        <?php
            // include connection to database
            include("database.php");

            //retrieving the cookie here - created in loginprocess.php
            $userId = $_COOKIE['varus_name']; 

            // Function to fetch user details by ID
            function getUserDetails($conn, $user)
            {
                $query = "SELECT * FROM studentdetails WHERE studentid = '$user'";
                $response = mysqli_query($conn, $query);
                if(mysqli_num_rows($response) > 0)
                {
                    return $response->fetch_assoc();
                }
                return false;
            }

            // Get user details
            $userDetails = getUserDetails($conn, $userId);

            if ($userDetails) {
                // Display user details
                echo "<p>Name: " . $userDetails['name'] . "</p>";
                echo "<p>StudentId: " . $userDetails['studentid'] . "</p>";
                echo "<p>DateofBirth: " . $userDetails['dob'] . "</p>";
                echo "<p>Address: " . $userDetails['address'] . "</p>";
                echo "<p>Mobile Number: " . $userDetails['contact'] . "</p>";
                echo "<p>Email: " . $userDetails['email'] . "</p>";
                
                echo '<button><a href="stdprofileedit.php"> Change Password</a></button>';

            } else {
                echo "<p class='error-message'>User not found.</p>";
            }

            // Close the database connection
            $conn->close();
        ?>
    </div>
</body>
</html>
