<?php 
define('URL', 'http://192.168.1.3/indra/');

 $host = 'localhost';
 $root = 'root';
 $pass = '';
 $data_base = 'clubevents';

 $conn = new mysqli($host, $root, $pass, $data_base);

 if($conn == false){
    die('Connection interupted!.. Try Again'.$conn->connect_error);
 }
 

?> 